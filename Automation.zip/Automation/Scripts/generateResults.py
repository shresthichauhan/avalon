import csv
from email.mime.nonmultipart import MIMENonMultipart
from email.charset import Charset, BASE64
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email import encoders
from sharedLib import *
from logger import *
import matplotlib.pyplot as plt
import csv
import datetime
import glob
import ConfigParser
import smtplib
import mimetypes
import matplotlib
matplotlib.use('Agg')

sut_IP = ''
sut_uname = ''
sut_pwd = ''
sut_IP_list = []

ipConfig_SharedLib = ConfigParser.ConfigParser()
ipConfig_path_SharedLib = os.path.abspath(
    os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'ipConfig.ini'))
ipConfig_SharedLib.read(ipConfig_path_SharedLib)

'''
def readCSV():
    csvFilePath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'TestResults', 'Results.csv'))
    passCount = 0
    failCount = 0
    with open(csvFilePath) as csvFile:
        logger.debug("Reading the results.csv file")
        csvReader = csv.reader(csvFile)
        for row in csvReader:
            if str(row[2]).strip() == "PASS":
                passCount += 1
            elif str(row[2]).strip() == "FAIL":
                failCount += 1
        logger.debug("Completed reading the results.csv file")
    logger.debug("Pass Count: " + str(passCount))
    logger.debug("Fail Count: " + str(failCount))
    return passCount, failCount
'''


def make_autopct(values):
    def my_autopct(pct):
        total = sum(values)
        val = int(round(pct*total/100.0))
        return '{p:.2f}%  ({v:d})'.format(p=pct, v=val)
    return my_autopct


def createChart(passCount, failCount):
    #passCount,failCount = readCSV()
    labels = ['Pass', 'Fail']
    values = [passCount, failCount]
    colors = ['green', 'red']
    fig1, ax1 = plt.subplots()
    logger.debug("Creating the PIE Chart")
    ax1.pie(values, labels=labels, autopct=make_autopct(
        values), colors=colors, startangle=90)
    ax1.axis('equal')
    plt.title("Automation Summary")
    imagePath = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'TestResults', 'summary.png'))
    plt.savefig(imagePath)
    # plt.savefig('../TestResults/summary.png')
    logger.debug("Chart image saved in local")
    return passCount, failCount


def generateCSVResults():
    saved = os.getcwd()
    testResultsPath = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, 'TestResults'))
    os.chdir(testResultsPath)
    # os.chdir("../TestResults")
    dir = glob.glob("*.txt")
    # print dir
    excelPath = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'TestResults', 'Results.csv'))
    create_file = open(excelPath, 'w+')
    #create_file = open('../TestResults/Results.csv', 'w+')
    passCount = 0
    failCount = 0
    for file in dir:
        logger.debug("File Name : " + str(file))
        print "File Name: ", file
        # print
        fname = file

        #resFile = open('../TestResults/Results.csv', 'a')
        num_lines = 0

        with open(excelPath, mode='a') as csvfile:
            # with open('../TestResults/Results.csv', mode='w') as csvfile:
            writer = csv.writer(csvfile, delimiter=',',
                                quotechar='"', quoting=csv.QUOTE_MINIMAL)
            with open(fname, 'r') as f:
                for line in f:
                    outPut = line.split(';')
                    writer.writerow([outPut[1], '=', outPut[2], outPut[3]])
                    if str(outPut[2]).strip() == "PASS":
                        passCount += 1
                    elif str(outPut[2]).strip() == "FAIL":
                        failCount += 1
                    num_lines += 1

        logger.debug("Number of lines : " + str(num_lines))
        logger.debug("Pass Count : " + str(passCount))
        logger.debug("Fail Count : " + str(failCount))
    os.chdir(saved)
    return passCount, failCount


'''
def generateCSVResults():
    saved = os.getcwd()
    os.chdir("../TestResults")
    dir = glob.glob("*.txt")
    # print dir
    create_file = open('../TestResults/Results.csv', 'w+')
    passCount = 0
    failCount = 0
    for file in dir:
        logger.debug("File Name : " + str(file))
        print "File Name: ", file
        #print
        fname = file
        resFile = open('../TestResults/Results.csv', 'a')
        num_lines = 0
        with open(fname, 'r') as f:
            for line in f:
                outPut = line.split(';')
                resFile.write(outPut[1] + ' ,=, ' + outPut[2])
                resFile.write("\n")
                if str(outPut[2]).strip() == "PASS":
                    passCount += 1
                elif str(outPut[2]).strip() == "FAIL":
                    failCount += 1
                num_lines += 1
        logger.debug("Number of lines : " + str(num_lines))
        logger.debug("Pass Count : " + str(passCount))
        logger.debug("Fail Count : " + str(failCount))
    os.chdir(saved)
    return passCount, failCount
'''
# Module to send the test results in mail


def sendEmail(utility_name):
    passCount, failCount = generateCSVResults()
    createChart(passCount, failCount)
    config = ConfigParser.ConfigParser()
    logger.debug("Reading the email config file")
    config_path = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'Datafeed', 'emailConfig.ini'))
    config.read(config_path)
    receiver = config.get('EMAILCONFIG', 'receiver').split(",")
    #default = "supraja.rakesh.dittakavi@intel.com,ambalavanan.m.m@intel.com,vivek.dharmarajan@intel.com,drashti.trivedi@intel.com".split(",")
    default = ["supraja.rakesh.dittakavi@intel.com"]
    #receiver = receiver + default
    sender = config.get('EMAILCONFIG', 'sender')
    #utility = config.get('EMAILCONFIG', 'utility')
    utility = utility_name.upper()
    platform = config.get('EMAILCONFIG', 'platform')
    #env = config.get('EMAILCONFIG', 'os')
    env = ""
    if utility.lower() == "utility_name":
        env = "Environment"
    else:
        #linux_os, win_os, efi_os = getOS()
        os_info = getOS()
        # if linux_os.lower() == 'yes':
        if os_info == 'LINUX':
            env = env + "Linux "
        # if  win_os.lower() == 'yes':
        if os_info == 'WINDOWS':
            env = env + "Windows "
        # if efi_os.lower() ==  'yes':
        if os_info == 'UEFI':
            env = env + "UEFI "
    message = MIMEMultipart('related')
    message['Subject'] = config.get(
        'EMAILCONFIG', 'subject') + " " + datetime.datetime.today().strftime('%d/%m/%Y')
    message['To'] = ", ".join(receiver)
    message['From'] = sender
    # We reference the image in the IMG SRC attribute by the ID we give it below
    text = 'Hi All,<br> PFB the Tools & Utility Automation Status <br><br>Utility Name: ' + utility + '<br>Platform: ' + platform + '<br>OS Environment: ' + env + '<br>Total Test Cases Executed: ' + \
        str(passCount+failCount) + '<br><img src="cid:image1"> <br> Note:- Detailed Test Results are available in the attached document for your reference. <br><br> Thanks,<br>Tools&Utility Team'
    msgText = MIMEText(text, 'html')
    message.attach(msgText)

    imagePath = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'TestResults', 'summary.png'))
    fp = open(imagePath, 'rb')
    #fp = open('../TestResults/summary.png', 'rb')
    msgImage = MIMEImage(fp.read())
    fp.close()

    # Define the image's ID as referenced above
    msgImage.add_header('Content-ID', '<image1>')
    message.attach(msgImage)
    logger.debug("Attaching the image to email")

    csvFilePath = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'TestResults', 'Results.csv'))
    fp = open(csvFilePath, 'rb')
    #ctype, encoding = mimetypes.guess_type(csvFilePath)
    #maintype, subtype = ctype.split("/", 1)
    #attachment = MIMEBase(maintype, subtype)
    # attachment.set_payload(fp.read())
    # fp.close()
    # encoders.encode_base64(attachment)
    #attachment.add_header("Content-Disposition", "attachment", filename=os.path.basename(csvFilePath))
    attachment = MIMENonMultipart('text', 'csv', charset='utf-8')
    cs = Charset('utf-8')
    cs.body_encoding = BASE64
    attachment.set_payload(fp.read())
    # print(fp.read())
    message.attach(attachment)
    attachment.add_header('Content-Disposition', 'attachment',
                          filename=os.path.basename(csvFilePath))
    fp.close()
    logger.debug("Attaching the csv file to email")

    try:
        smtpObj = smtplib.SMTP('smtp.intel.com', 25)
        receiver = receiver + default
        smtpObj.sendmail(sender, receiver, message.as_string())
        logger.debug("Successfully sent email")
        print "Successfully sent email"
    except Exception, msg:
        print(str(msg))
        logger.debug(str(msg))
        logger.debug("Unable to send email")
        print "Error: unable to send email"

# receiversendEmail()
