from OFULinuxCommands import *
from logger import *
from Libraries.ssh import *
from sharedLib import *
import ConfigParser
import os

#SUT = config.get('OFU', 'SUT')
#usrName = config.get('OFU', 'usrName')
#usrPwd = config.get('OFU', 'usrPwd')

#SUT = config.get('SYSCFG', 'SUT')
#usrName = config.get('SYSCFG', 'usrName')
#usrPwd = config.get('SYSCFG', 'usrPwd')

#Transfer the config file and cap files from local machine to host machine
def fileTransfer(server, localPath, remotePath):
    #server = connectToHost()
    logger.debug("Transfering file from " + localPath + " to " + remotePath)
    server.put(localPath, remotePath)
    #linux_os, win_os, efi_os = getOS()
    os_info = getOS()
    #if linux_os == 'Yes':
    if os_info == 'LINUX':
        unzipCmd = UNZIP_TAR_GZ_CMD + " " + remotePath + " -C /tmp/"
        logger.debug("Executing command : " + unzipCmd)
        result = executeCommand(server, unzipCmd)
    else:
        rm_tar_files = r'cd C:\Users\Administrator\Desktop' + r' && del *.tar'
        result = executeCommand(server, rm_tar_files)
        logger.debug("Result: rm *.tar" + ''.join(result))
        gzip_cmd = r'cd C:\Users\Administrator\Desktop' + r' && C:\cygwin64\bin\gzip.exe -d temp.tar.gz'
        result = executeCommand(server, gzip_cmd)
        logger.debug("Result: gzip_cmd" + ''.join(result))
        tar_cmd = r'cd C:\Users\Administrator\Desktop' + r' && C:\cygwin64\bin\tar.exe -xvf temp.tar'
        result = executeCommand(server, tar_cmd)
        logger.debug("Result: tar_cmd" + ''.join(result))
    logger.debug("Extracted the " + remotePath + " file")

#Checks if a file or directory actually exists or not. Absolute path needs to be given
def checkFileExists(server, pkgName):
    #linux_os, win_os, efi_os = getOS()
    os_info = getOS()
    #if linux_os == 'Yes':
    if os_info == 'LINUX':
        command = LIST_CMD + " " + pkgName
    else:
        command = 'dir ' + pkgName
    result = executeCommand(server, command)
    result = "".join(result)
    if "No such file or directory" in result or "The system cannot find the file specified" in result:
        return False
    else:
        return True

#Checks of the package is already present else gunzip the package and call the fileTransfer function
def transferFiles(SUT, localPath, remotePath):
    try:
        pkgName = os.path.basename(localPath)
        server = connectToHost(SUT)
        logger.debug("Connection Succeded")
        #linux_os, win_os, efi_os = getOS()
        os_info = getOS()
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            file_check_path = remotePath + "\"" + pkgName + "\""
            logger.debug("Linux OS path: " +str(file_check_path))
        else:
            file_check_path = remotePath + "\\" + pkgName + "\\"
            logger.debug("Windows OS path: " + str(file_check_path))

        if not checkFileExists(server, file_check_path):
            file = createTar(localPath)
            logger.debug('Created ' + file + ' file')
            #if linux_os == 'Yes':
            if os_info == 'LINUX':
                fileTransfer(server, file, remotePath + os.path.basename(file))
            else:
                fileTransfer(server, file, remotePath + '\\' + os.path.basename(file))
        else:
            logger.debug('Package ' + pkgName + " already present")
        server.close()
    except Exception, msg:
        logger.debug("Unable to transfer files due to Exception : " + str(msg))


def transferRemoteFiles(server, localPath, remotePath):
    try:
        # localPath = r"/root/temp.tar.gz"
        localPath = 'temp.tar.gz'
        logger.debug("Connection Succeeded")

        logger.debug("Creating Remote Tar file of Sysinfo LogFiles folder")
        remotePath = createRemoteTar(server, r'LogFiles')

        #server.get(r"temp.tar.gz", r'/home/Shanghai/Automation/Scripts/temp.tar.gz')
        server.get(r"temp.tar.gz", os.getcwd()+r'/temp.tar.gz')

    except Exception, msg:
        logger.debug("Unable to transfer files due to Exception : " + str(msg))


#Parses the current BIOS Version from the input
def getCurrentBIOSVersion(input):
    for line in input:
        if line.find("Primary BIOS Version:") is not -1:
            arr = list(line.split())
            return arr[3]

def getCurrentBackupBIOSVersion(input):
    for line in input:
        if line.find("Secondary BIOS Version:") is not -1:
            arr = list(line.split())
            return arr[3]
#Parses the Target BIOS Version from input
def getTargetBIOSVersion(input):
    for line in input:
        if "BIOS Version" in line:
            arr = list(line.split())
            return arr[2]

#Parses the current BMC Version from the input
def getCurrentBMCVersion(input):
    for line in input:
        if "Op Code" in line:
            arr = list(line.split())
            return arr[2]

#Parses the Target BMC Version from input
def getTargetBMCVersion(input):
    for line in input:
        if "Op Code" in line:
            arr = list(line.split())
            return arr[3]

#Parses the current ME Version from the input
def getCurrentMEVersion(input):
    for line in input:
        if "ME Firmware Version" in line:
            arr = list(line.split())
            logger.debug("CurrentMEVersion_Retrieved is: " + arr[3])
            return arr[3]

#Parses the current ME Version from the input
def getTargetMEVersion(input):
    logger.debug("Get Target ME Version: " + str(input))
    for line in input:
        logger.debug("line:"+ line)
        if "ME Version" in line:
            arr = list(line.split())
            logger.debug("Arr:" + str(arr))
            logger.debug("TargetMEVersion_Retrieved is: " +arr[2])
            return arr[2]

#Parses the current SDR Version from the input
def getCurrentSDRVersion(input):
    for line in input:
        if "SDR Version" in line:
            arr = list(line.split())
            return arr[4]

#Parses the target SDR Version from the input
def getTargetSDRVersion(input):
    for line in input:
        if "SDR Version" in line:
            arr = list(line.split())
            return arr[2]

#Split the provided command and return it
def recognizeCommand(command):
    cmd = command.split()
    return cmd

#Form the flash BIOS command using the provided input
def buildCommand(cmd,filePath):
    #Start Drashti
    config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
    logger.debug("config_path == " + str(config_path))
    config = ConfigParser.ConfigParser()
    config.read(config_path)
    windows_path = config.get('OFU', 'OFU_WD')
    logger.debug("Fetching the value of WD path: " + str(windows_path))
    #linux_os, win_os, efi_os = getOS()
    os_info = getOS()
    logger.debug("OS : " + os_info)
    #End Drashti
    if "nac" in cmd:
        cmd1 = str(cmd)
        temp6 = cmd1.split()[-1]
        temp5 = cmd1.split()[-3]
        temp4 = cmd1.split()[-4]
        temp3 = cmd1.split()[-5]
        temp2 = cmd1.split()[-6]
        temp1 = cmd1.split()[-7]
        #Start Drashti
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            logger.debug("Command for frusdr: " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath + " " + temp6)
            return temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath + " " + temp6
        #elif win_os == 'Yes':
        elif os_info == 'WINDOWS':
            logger.debug("Command for frusdr: " + "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath + " " + temp6)
            return "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath + " " + temp6
        #End Drashti

    if "-e" in cmd:
        cmd1 = str(cmd)
        temp5 = cmd1.split()[-2]
        temp4 = cmd1.split()[-3]
        temp3 = cmd1.split()[-4]
        temp2 = cmd1.split()[-5]
        temp1 = cmd1.split()[-6]
        temp0 = cmd1.split()[-7]
        #Drashti Addded if block for building command separately for Windows and Linux
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            logger.debug("going in if clause for linux os for echo in command")
            logger.debug("Command for frusdr: " + temp0 + " " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath)
            return temp0 + " " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath
        #elif win_os == 'Yes':
        elif os_info == 'WINDOWS':
            logger.debug("going in if clause for windows os for echo in command")
            logger.debug("Command for frusdr: " + "cd " + windows_path + " && " + temp0 + " " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath)
            return "cd " + windows_path + " && " + temp0 + " " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath
        #End Drashti

    elif "echo" in cmd:
        logger.debug("Building the command :" + cmd)
        cmd1 = str(cmd)
        temp5 = cmd1.split()[-2]
        temp4 = cmd1.split()[-3]
        temp3 = cmd1.split()[-4]
        temp2 = cmd1.split()[-5]
        temp1 = cmd1.split()[-6]
        #Drashti Addded if block for building command separately for Windows and Linux
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            logger.debug("going in echo part for linux os")
            logger.debug("Command for frusdr: " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath)
            return temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath
        #elif win_os == 'Yes':
        elif os_info == 'WINDOWS':
            logger.debug("going in echo part for windows os")
            logger.debug("Command for frusdr: " + "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath)
            return "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + temp3 + " " + temp4 + " " + temp5 + " " + filePath
        #End Drashti
    else :
        cmd1 = str(cmd)
        temp1 = cmd1.split()[-3]
        temp2 = cmd1.split()[-2]
        #Start Drashti
        #if linux_os == 'Yes':
        if os_info == 'LINUX':        
            logger.debug("Command for rest" + temp1 + " " + temp2 + " " + filePath)
            return temp1 + " " + temp2 + " " + filePath
        #elif win_os == "Yes" :
        elif os_info == 'WINDOWS':
            logger.debug("Command for rest" +  "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + filePath)
            return "cd " + windows_path + " && " + temp1 + " " + temp2 + " " + filePath
        #End Drashti

#Based on the component passed, execute the command and parses the component's target version
def getTargetComponent(SUT, component, filePath):
    try:
        server = connectToHost(SUT)
        # Start Drashti
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
        logger.debug("config_path == " + config_path)
        config = ConfigParser.ConfigParser()
        config.read(config_path)
        windows_path = config.get('OFU', 'OFU_WD')
        logger.debug("Fetching the value of WD path: " + windows_path)
        #linux_os, win_os, efi_os = getOS()
        os_info = getOS()
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            targetComponentCommand = GET_TARGET_INFO_CMD + " " + filePath
        #elif win_os == 'Yes':
        elif os_info == 'WINDOWS':
            targetComponentCommand = "cd " + windows_path + " && "  + GET_TARGET_INFO_CMD + " " + filePath
        #End Drashti
        #targetComponentCommand = GET_TARGET_INFO_CMD + " " + filePath
        logger.debug("Target Component Command: "+filePath)
        result = executeCommand(server, targetComponentCommand)
        if 'bios' in component.lower():
            componentVersion = getTargetBIOSVersion(result)
            logger.info('Target BIOS Version : ' + str(componentVersion))
        elif 'bmc' in component.lower():
            componentVersion = getTargetBMCVersion(result)
            logger.info('Target BMC Version : ' + str(componentVersion))
        elif 'sdr' in component.lower():
            componentVersion = getTargetSDRVersion(result)
            logger.info('Target SDR Version : ' + str(componentVersion))
        elif 'me' in component.lower():
            componentVersion = getTargetMEVersion(result)
            logger.info('Target ME Version : ' + str(componentVersion))
        elif 'all' in component.lower():
            componentVersion = getTargetALLVersion(result)
            logger.info('Target ALL Versions : ' + str(componentVersion))
        server.close()
        if componentVersion == None:
            logger.debug("Unable to get the Target Component version")
            return False
        else:
            return componentVersion
    except Exception, msg:
        logger.debug("Unable to get the Target Component due to Exception: " + str(msg))
#Based on the component passed, execute the command and parse the component's current version
def getCurrentComponent(SUT, component):
    try:
        logger.debug("Retrieving Current Version")
        server = connectToHost(SUT)
        # Start Drashti
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
        logger.debug("config_path == " + config_path)
        config = ConfigParser.ConfigParser()
        config.read(config_path)
        windows_path = config.get('OFU', 'OFU_WD')
        logger.debug("Fetching the value of WD path: " + windows_path)
        #linux_os, win_os, efi_os = getOS()
        os_info = getOS()
        #if linux_os == 'Yes':
        if os_info == 'LINUX':
            result = executeCommand(server, GET_CURRENT_INFO_CMD)
        #elif win_os == 'Yes':
        elif os_info == 'WINDOWS':
            currentComponentCommand = "cd " + windows_path + " && " + GET_CURRENT_INFO_CMD
            logger.info("The command used for getting current Component: " + currentComponentCommand)
            result = executeCommand(server, currentComponentCommand)
        # End Drashti
        #result = executeCommand(server, GET_CURRENT_INFO_CMD)
        if 'backupbios' in component.lower():
            componentVersion = getCurrentBackupBIOSVersion(result)
            logger.info('Current BIOS Version : ' + str(componentVersion))
        elif 'bios' in component.lower():
            componentVersion = getCurrentBIOSVersion(result)
            logger.info('Current BIOS Version : ' + str(componentVersion))
        elif 'bmc' in component.lower():
            componentVersion = getCurrentBMCVersion(result)
            logger.info('Current BMC Version : ' + str(componentVersion))
        elif 'sdr' in component.lower():
            componentVersion = getCurrentSDRVersion(result)
            logger.info('Current SDR Version : ' + str(componentVersion))
        elif 'me' in component.lower():
            componentVersion = getCurrentMEVersion(result)
            logger.info('Current ME Version : ' + str(componentVersion))
        elif 'all' in component.lower():
            componentVersion = getCurrentALLersion(result)
            logger.info('Target ALL Versions : ' + str(componentVersion))
        server.close()
        return componentVersion
    except Exception, msg:
        logger.debug("Unable to get the Current Component due to Exception: " + str(msg))

#Reboot the SUT and check if its up and running within 5 mins
def rebootSUT(SUT, server):
    #result = executeCommand(server, REBOOT_CMD)
    # Added by Drashti for restart command for Linux and Windows
    #linux_os, win_os, efi_os = getOS()
    os_info = getOS()
    #if linux_os == 'Yes':
    if os_info == 'LINUX':
        result = executeCommand(server, REBOOT_CMD)
    #elif win_os == 'Yes':
    elif os_info == 'WINDOWS':
        result = executeCommand(server, REBOOT_CMD_WIN)
        #End Drashti
    logger.info('Rebooting the ' + SUT['ip'])

    '''
    try:
        attempt = 0
        iterFlag = 0
        while attempt < 10:
            logger.debug("Waiting for 60 seconds")
            time.sleep(60)
            logger.debug("Attempting ping")
            if ping(SUT['ip']) == 0:
                logger.debug(SUT['ip'] + ' is up and running')
                return True
            if attempt > 9 and iterFlag < 3:
                iterFlag += 1
                logger.debug("Resetting the server for the: " + str(iterFlag) +" attempt")
                reset_ping = bmc_info("power reset")
                attempt = 0

            attempt += 1
    except:
        logger.debug("Unable to connect to SUT['ip'] ")
        
    '''


    for attempt in range(1, 10):
        logger.debug("Waiting for 60 seconds")
        time.sleep(60)
        logger.debug("Attempting ping")
        if ping(SUT['ip']) == 0:
            logger.debug(SUT['ip'] + ' is up and running')
            return True
        if attempt > 9:
            logger.debug("Cannot establish connection with " + SUT['ip'])
            return False

def updateLinuxComponent(SUT, component, command, filePath, expectedResult,test_name):
    try:
        #targetComponentVersion = getTargetComponent(SUT, component,filePath)
        command = buildCommand(command, filePath)
        #command = buildCommand(command.split(),filePath)
        server = connectToHost(SUT)
        result = executeCommand(server, command)
        logger.info('Updating ' + component + ' log : ' + ''.join(result))
        result = "".join(result)
        if 'nvram' in test_name.lower() or 'sdrupdate_bmc' in test_name.lower():
            return result
        else:
            result = compare_string(server, result, expectedResult)
            if result == True:
                logger.debug("No errors were found during updating " + component)
                message = expectedResult
                if "errChk" not in expectedResult and rebootSUT(SUT, server):
                    logger.debug("Checking if going into if clause of reboot")
                    targetComponentVersion = getTargetComponent(SUT, component, filePath)
                    logger.info("Obtained the target component version")
                    currentComponentVersion = getCurrentComponent(SUT, component)
                    logger.info("Obtained the current component version")
                    result = compare_string("", currentComponentVersion, 'msg>' + str(targetComponentVersion))
                    #return currentComponentVersion, targetComponentVersion, flashResult
                else:
                    logger.debug("Negative Test case passed.")
            #elif flashResult == True and "error" in result.lower():
            #    logger.debug(component + " Update Failed due to Negative test case execution")
            #    flashResult = component + " Update Failed due to Negative test case execution"
            #    return "currentVersion", "targetVersion", flashResult
            else:
                message = component + " Update Failed"
                logger.debug(component + " Update Failed")
        return result, message

    except Exception, msg:
        logger.debug("Unable to update the " + component + " due to Exception: " + str(msg))

def getCurrentALLersion(input):
    logger.debug("Entering into get current version for ALL")
    currentBIOS = getCurrentBIOSVersion(input)
    currentBMC = getCurrentBMCVersion(input)
    currentME = getCurrentMEVersion(input)
    currentSDR = getCurrentSDRVersion(input)
    # for line in input:
    #     if line.find("Primary BIOS Version:") is not -1:
    #         arr = list(line.split())
    #         currentBIOS = arr[3]
    # for line in input:
    #     if "Op Code" in line:
    #         arr = list(line.split())
    #         currentBMC = arr[2]
    # for line in input:
    #     if "ME Firmware Version" in line:
    #         arr = list(line.split())
    #         logger.debug("CurrentMEVersion_Retrieved is: " + arr[3])
    #         currentME = arr[3]
    # for line in input:
    #     if "SDR Version" in line:
    #         arr = list(line.split())
    #         currentSDR = arr[4]

    componentCurrentVersion = str([currentBIOS, currentBMC, currentME, currentSDR])
    logger.debug("Current Component Version for all :" + componentCurrentVersion)
    return componentCurrentVersion

def getTargetALLVersion(input):
    logger.debug("Getting the target version for all test case")
    targetBIOS = 'null'
    targetBMC = 'null'
    targetME = 'null'
    targetSDR = 'null'
    targetBIOS = getTargetBIOSVersion(input)
    targetBMC = getTargetBMCVersion(input)
    targetME = getTargetMEVersion(input)
    targetSDR = getTargetSDRVersion(input)
    # for line in input:
    #     if "BIOS Version" in line:
    #         arr = list(line.split())
    #         targetBIOS = arr[2]
    # for line in input:
    #     if "Op Code" in line:
    #         arr = list(line.split())
    #         targetBMC = arr[3]
    # for line in input:
    #     logger.debug("line:"+ line)
    #     if "ME Version" in line:
    #         arr = list(line.split())
    #         logger.debug("Arr:" + str(arr))
    #         logger.debug("TargetMEVersion_Retrieved is: " +arr[2])
    #         targetME = arr[2]
    # for line in input:
    #     if "SDR Version" in line:
    #         arr = list(line.split())
    #         targetSDR = arr[2]

    TargetVersion = str([targetBIOS,targetBMC,targetME,targetSDR])
    logger.debug(
        "targetBIOS: " + targetBIOS + ",targetBMC: " + targetBMC + ",targetME: " + targetME + "targetSDR: " + targetSDR)
    logger.debug("Target Version for all: " + TargetVersion)
    return TargetVersion
