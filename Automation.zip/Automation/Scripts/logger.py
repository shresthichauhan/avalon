import logging
import os
import time
import platform
import logging.config
#from sharedLib import *

logger = logging.getLogger()


def logInit(fileOption):

    logLevel = logging.DEBUG
    logPath = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'TestResults', 'debugLogs'))

    if not os.path.exists(logPath):
        os.makedirs(logPath)
    '''
    if platform.system() == "Linux":
        fileName = logPath + "/" + fileOption + time.strftime("%Y%m%d%H%M%S") + ".log"
    elif  platform.system() == "Windows":
        fileName = logPath + "\\" + fileOption + time.strftime("%Y%m%d%H%M%S") + ".log"
    '''
    if platform.system() == "Linux":
        fileName = logPath + "/" + fileOption + \
            time.strftime("%Y%m%d%H%M%S") + ".log"
        tempPath = '/temp/'
        print "Log file : " + fileName
    elif platform.system() == "Windows":
        fileName = logPath + "\\" + fileOption + \
            time.strftime("%Y%m%d%H%M%S") + ".log"
        tempPath = 'C:\\temp\\'
    if not os.path.exists(tempPath):
        os.makedirs(tempPath)

    #fileName = logPath + "\\" + fileOption + time.strftime("%Y%m%d%H%M%S")+".log"
    #logFormat = '%(asctime)s - %(module)s - %(levelname)s -->> %(message)s'
    logFormat = '%(asctime)s - %(filename)s:%(lineno)s - %(funcName)s() - %(levelname)s -->> %(message)s'
    dateFormat = '%Y-%m-%d %H:%M:%S'
    logging.basicConfig(filename=fileName, format=logFormat,
                        datefmt=dateFormat, filemode='w', level=logLevel)
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(logging.Formatter(logFormat, dateFormat))
    logger.addHandler(ch)
