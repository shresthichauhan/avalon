#!/usr/bin/python

from mainstep import *
import sys
from logger import *
from sharedLib import *
from generateResults import *


# ------------------Function to assign tool name according to the option selected and4 read Config.ini------------------
def assign_file_name(option):
    file_name = "utility_name"
    folder_name = "utility_name"

    if option == 1:
        folder_name = "azureps"
        logInit('azure')
    elif option == 2:
        folder_name = "imsm"
        logInit('imsm')
    elif option == 3:
        folder_name = "sdptool"
        logInit('sdptool')
    elif option == 4:
        folder_name = "ofu"
        logInit('ofu')
    elif option == 5:
        folder_name = "fwpiaupd"
        logInit('fwpiaupd')
    elif option == 6:
        folder_name = "syscfg"
        logInit('syscfg')
    elif option == 7:
        folder_name = "iflash32"
        logInit('iflash32')
    elif option == 8:
        folder_name = "selviewer"
        logInit('selviewer')
    elif option == 9:
        folder_name = "frusdr"
        logInit('frusdr')
    elif option == 10:
        folder_name = "sysinfo"
        logInit('sysinfo')
    elif option == 11:
        folder_name = "sph"
        logInit('sph')
    elif option < 0:
        teardown()
    elif option == 0:
        print "Executing Hidden switch 0 to generate Results csv explicitly"
        sendEmail(file_name)
        # generateCSVResults()
        print "Consolidation of results from above files and mail sent successfully"
    else:
        exit()

    if option > 0:

        print "Let's start the test cases"

        # Reading required fields of appropriate utility from Config.ini file
        logger.debug('Reading from Config.ini')
        input_txt_list = txt_list_fetch(folder_name)
        logger.debug("Input files to be executed: " + str(input_txt_list))
        # print input_txt_list
        for file_name in input_txt_list:
            logger.debug("Current Input file: " + str(file_name) + ".txt")
            # print file_name
            print "To config_paths : %s" % (folder_name)
            config_paths(folder_name, file_name, option)
            # generateCSVResults()
            sendEmail(file_name)
# ---------------------------------------assign_file_name definition ends-----------------------------------------------


opt_length = len(sys.argv)
if opt_length < 2:
    # Use the below loadBMCConsole() to fetch BMC values
    # loadBMCConsole()
    # Display Utilities and Tools Menu
    print("Utilities And Tools:\n 1. AzurePS\n 2. IMSM\n 3. SDP Tool\n 4. OFU\n 5. FWUPDPID\n 6. SYSCFG\n 7. iFLASH32\n 8. SELVIEWER\n 9. FRUSDR\n 10. SYSINFO\n 11. SPH\n 12. EXIT")
    option = int(input("Enter your option:"))
    assign_file_name(option)
else:
    # Bypass menu and execute multiple tools, if needed, directly from command line
    for j in range(1, opt_length):
        option = int(sys.argv[j])
        assign_file_name(option)
