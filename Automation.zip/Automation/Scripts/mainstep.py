from triggers import trigger_shell, trigger_shell_ib
from sharedLib import *
from logger import *
import os
import time

# Get Config.ini path
import ConfigParser
config = ConfigParser.ConfigParser()
config_path = os.path.abspath(os.path.join(
    os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
config.read(config_path)

# Global Variables
upd_pkg = ''
down_pkg = ''
shell_path = ''
UTILITY_NAME = ''

efi = ''
linux = ''
windows = ''

# function to fetch the 'utility'_'bat_or_fat'.txt


def test_environment_fetch():
    global efi, linux, windows
    tst_list = []
    efi = config.get('TC_EXECUTION', 'UEFI')
    linux = config.get('TC_EXECUTION', 'LINUX')
    windows = config.get('TC_EXECUTION', 'WINDOWS')
    logger.debug("From config.ini, EFI = " + str(efi) +
                 ",Linux = " + str(linux) + ",Windows = " + str(windows))

    if efi.lower() == 'yes':
        tst_list.append('UEFI')
    if linux.lower() == 'yes':
        tst_list.append('LINUX')
    if windows.lower() == 'yes':
        tst_list.append('WINDOWS')

    logger.debug("Environments : " + str(tst_list))
    return tst_list


def txt_list_fetch(file_name):
    input_txt_list = []
    bat = config.get('TC_EXECUTION', 'BAT')
    fatp1 = config.get('TC_EXECUTION', 'FATP1')
    fatp2 = config.get('TC_EXECUTION', 'FATP2')
    fatp3 = config.get('TC_EXECUTION', 'FATP3')
    logger.debug("From config.ini, BAT = " + str(bat) + ",FATP1 = " +
                 str(fatp1) + ",FATP2 = " + str(fatp2) + ",FATP3 = " + str(fatp3))

    if bat.lower() == 'yes':
        input_txt_list.append(file_name + '_bat')
    if fatp1.lower() == 'yes':
        input_txt_list.append(file_name + '_fatp1')
    if fatp2.lower() == 'yes':
        input_txt_list.append(file_name + '_fatp2')
    if fatp3.lower() == 'yes':
        input_txt_list.append(file_name + '_fatp3')

    logger.debug("Input files to be executed : " + str(input_txt_list))
    return input_txt_list


# Function to parse Config.ini
def config_paths(folder_name, file_input, option):
    global UTILITY_NAME, shell_path
    global efi, linux, windows
    wd_path = ''
    # Source and Destination paths
    source = os.path.abspath(os.path.join(os.path.dirname(
        __file__), os.pardir, 'Datafeed', folder_name.upper(), file_input + '.txt'))
    logger.debug('Input File : ' + source)
    destination = os.path.abspath(os.path.join(
        os.path.dirname(__file__), os.pardir, 'TestResults', file_input))
    logger.debug('Result File Location : ' + destination)

    test_key_list = test_environment_fetch()

    print test_key_list

    UTILITY_NAME = folder_name.upper()

    print UTILITY_NAME

    if 'azureps' in file_input:
        logger.debug('Reading Azure details from Config.ini')
        shell_path = config.get('AZUREPS', 'ShellPath').replace("\"", "")
        wd_path = config.get('AZUREPS', 'AzureWD').replace("\"", "")
        setUtilityName('AzurePS')

    elif 'imsm' in file_input:
        logger.debug('Reading IMSM details from Config.ini')
        shell_path = config.get('IMSM', 'ShellPath')
        wd_path = config.get('IMSM', 'imsmWD').replace("\"", "")
        setUtilityName('IMSM')

    elif 'sdptool' in file_input:
        logger.debug('Reading SDPTool details from Config.ini')
        shell_path = config.get('SDP', 'ShellPath').replace("\"", "")
        wd_path = config.get('SDP', 'sdptoolWD').replace("\"", "")
        setUtilityName('SDP')

    elif 'ofu' in file_input:
        logger.debug('Reading OFU details from Config.ini')
        wd_path = config.get('OFU', 'OFU_WD')
        shell_path = ""
        setUtilityName('OFU')

    elif 'fwpiaupd' in file_input:
        logger.debug('Reading FWPIAUPD details from Config.ini')
        # efi = config.get('FWPIAUPD', 'EFI')
        if efi == 'Yes':
            shell_path = os.path.abspath(
                os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility'))
        else:
            shell_path = ""

        # "/usr/local/ism/ism_scripts/SDPTool/"
        wd_path = config.get('FWPIAUPD', 'FWPIAUPD_WD')
        setUtilityName('FWPIAUPD')

    elif 'iflash32' in file_input:
        logger.debug('Reading IFLASH32 details from Config.ini')
        shell_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility'))
        # "/usr/local/ism/ism_scripts/SDPTool/"
        wd_path = config.get('IFLASH32', 'IFLASH32_WD')
        setUtilityName('IFLASH32')

    elif 'frusdr' in file_input:
        logger.debug('Reading the FRUSDR details from Config.ini')
        shell_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility'))

        wd_path = config.get('FRUSDR', 'FRUSDR_WD')
        setUtilityName('FRUSDR')

    elif 'syscfg' in file_input:
        logger.debug('Reading SYSCFG details from Config.ini')
        shell_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility'))
        wd_path = config.get('SYSCFG', 'syscfg_WD')
        setUtilityName('SYSCFG')

    elif 'selviewer' in file_input:
        logger.debug('Reading SELVIEWER details from Config.ini')
        #efi = config.get('SELVIEWER', 'EFI')
        if efi == 'Yes':
            shell_path = os.path.abspath(
                os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility'))
        else:
            shell_path = ""
        # shell_path = ""
        #  config.get('SELVIEWER', 'shell_path')
        wd_path = config.get('SELVIEWER', 'selviewer_WD')
        setUtilityName('selviewer')
        logger.debug("Working Directory Path: " + str(wd_path))

    elif 'sysinfo' in file_input:
        logger.debug('Reading SYSINFO details from Config.ini')
        # efi = config.get('SYSINFO', 'EFI')
        if efi == 'Yes':
            logger.debug(
                "Setting Shell Path as per EFI to the Package location")
            shell_path = os.path.abspath(
                os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/Utility/UEFI'))
        else:
            logger.debug("Retrieving Shell Path from Config.ini file")
            shell_path = config.get('SYSINFO', 'ShellPath')
        wd_path = ''
        setUtilityName('SYSINFO')

    elif 'sph' in file_input:
        logger.debug('Reading SPH details from Config.ini')
        setUtilityName('SPH')

    # Read appropriate utility.txt input file from Datafeed
    '''
    l, w, e = os_check()
    print "Linux: ", l
    print "Windows: ", w
    print "EFI: ", e
    logger.debug("Linux, Windows, EFI = " + str(l) + "," + str(w) + "," + str(e))
    '''

    logger.debug('Reading utilities Input Files')
    try:
        for test_key in test_key_list:
            logger.debug("Executing tcs in " + str(test_key))
            test_name, delay, shellCmd, shell_expected_out, delay, length = read_txt(
                source, test_key)

            print test_name, delay, shellCmd, shell_expected_out, delay, length

            os_info = getOS()
            # OOB Tools: Trigger appropriate commands and write the results into the test results folder
            logger.debug('Checking for IB/OOB Utility Flow')
            if option == 1 or option == 2 or option == 3:
                logger.debug('OOB Utility')
                for i in range(length):
                    print "\n========================== Line No - ", i+1, "=========================="
                    logger.debug("\n========================== Line No - " +
                                 str((i + 1)) + "==========================")
                    print "\nName:", test_name[i]
                    logger.debug("\nName:" + test_name[i] + "\n")
                    TC_Name = getTestCaseName(test_name[i])
                    if "sdp" in shellCmd[i].lower():
                        if "tar" in test_name[i].lower():
                            wd_path = os.path.abspath(os.path.join(os.path.dirname(
                                __file__), os.pardir, 'Utilities_Packages', 'SDPTOOL', 'Installer'))+"/"

                        elif "install" in test_name[i].lower():
                            # all_subdirs = os.listdir('/')
                            # for folder_name in all_subdirs:
                            #    if "SDP" in folder_name:
                            #        wd_path=os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages','SDPTOOL','Installer',folder_name))+"/"
                            installer_dir = os.path.abspath(os.path.join(os.path.dirname(
                                __file__), os.pardir, 'Utilities_Packages', 'SDPTOOL', 'Installer'))
                            # print installer_dir
                            logger.debug(
                                "Installer Directory: " + str(installer_dir))
                            all_subdirs = os.listdir(installer_dir)
                            # print all_subdirs
                            logger.debug(
                                "All Sub Directories: " + str(all_subdirs))
                            for folder_name in all_subdirs:
                                if "SDP" in folder_name and "tar" not in folder_name:
                                    wd_path = os.path.abspath(os.path.join(os.path.dirname(
                                        __file__), os.pardir, 'Utilities_Packages', 'SDPTOOL', 'Installer', folder_name)) + "/"
                        else:
                            wd_path = os.path.abspath(os.path.join(os.path.dirname(
                                __file__), os.pardir, 'TestResults', 'debugLogs'))+"/"

                    result, message = trigger_shell(
                        shell_path, test_name[i], shellCmd[i], shell_expected_out[i], wd_path, option)
                    if "step" not in test_name[i].lower():
                        # write_txt(destination, test_name[i], result, message, i)
                        write_txt(
                            destination, test_name[i], shellCmd[i], result, message)

                    time.sleep(int(delay[i]))

            # Inband Tools: Trigger appropriate commands and write the results into the test results folder
            if option == 4 or option == 5 or option == 6 or option == 7 or option == 8 or option == 9 or option == 10 or option == 11:
                logger.debug('Inband or SPH Utility')
                component = ''
                i, j = 0, 0

                if option != 11 and efi.lower() == 'yes' and 'upgrade' not in test_name[i].lower() and 'downgrade' not in test_name[i].lower():
                    shell_path = os.listdir(os.path.join(os.path.dirname(
                        __file__), os.pardir, 'Utilities_Packages/Utilities/'+UTILITY_NAME))[0]
                    uefi_path = config.get(UTILITY_NAME, 'uefi')
                    shell_path = os.path.abspath(os.path.join(os.path.dirname(
                        __file__), os.pardir, 'Utilities_Packages/Utilities/'+UTILITY_NAME)) + '/' + shell_path + '/' + uefi_path
                    logger.debug("UEFI binary path is: " + str(shell_path))

                while i < length:
                    # ----------EFI Group creation---------------
                    if "EG_Start" in test_name[i]:
                        print "\n=================== EFI Group Test Cases Triggered ====================="
                        logger.debug('EFI Group Creation Started.')
                        logger.debug("Emptying the efi deploy list")
                        efi_deploy_list = []
                        for j in range(i + 1, length):
                            if "EG_End" not in test_name[j]:
                                print "Tests Triggered: ", test_name[j]
                                logger.debug(
                                    "Tests Triggered: " + str(test_name[j]))

                                # Below code is to replace {} in the test cmd, if there is a corresponding Key in the config.ini
                                # Ex: Config.ini has FRUSIZE = 120
                                #     Test Cmd = frusdr.efi {FRUSIZE} -i
                                if option == 5 or option == 6 or option == 8 or option == 9:
                                    if re.search("{[\w._]+}", shellCmd[j]):
                                        config_value = re.findall(
                                            "{([\w._]+)}", shellCmd[j])[0]
                                        config_parse_value = config.get(
                                            UTILITY_NAME, config_value).replace('\"', '')
                                        shellCmd[j] = shellCmd[j].replace(
                                            config_value, config_parse_value).replace('{', '').replace('}', '')

                                print "Cmd: ", shellCmd[j]
                                logger.debug("Cmd: " + str(shellCmd[j]))
                                print "\n"
                                logger.debug(
                                    "Appended the TestName, Shell Cmd, Expected Output to the list: Line-" + str(j))
                                efi_deploy_list.append(
                                    [test_name[j], shellCmd[j], shell_expected_out[j]])
                            else:
                                break
                        i = j
                        # print("I value is: ", str(i))

                        if "EG_End" in test_name[i]:
                            logger.debug('EFI Group Creation Ended.')
                            # print efi_deploy_list
                            if efi_deploy_list:
                                logger.debug('EFI Group List: ' +
                                             str(efi_deploy_list))
                                create_deploy(shell_path, efi_deploy_list)
                                output, error = efi_execute(
                                    UTILITY_NAME, shell_path)
                                # print output
                                logger.debug(
                                    "EFI Execution Output: " + str(output))
                                create_file_text(
                                    '/temp/', 'temp_output.txt', output, 'w+')
                                efi_file_split()
                                efi_output_verify(
                                    output, error, efi_deploy_list)

                        i = i + 1
                        # -----------EFI Group execution END----------
                        if i == length:
                            logger.debug("End of Input File reached")
                            # print("End of Input File reached")
                            break
                    elif "upd_ini" in test_name[i].lower() and os_info == "UEFI":
                        print "\n========================== Line No - ", i + 1, "=========================="
                        logger.debug(
                            "\n========================== Line No - " + str((i + 1)) + "==========================\n")
                        print "\nName:", test_name[i]
                        logger.debug("\nName:" + test_name[i] + "\n")
                        logger.debug("Changing Values in .ini file")
                        efi_stream_editor(shell_path, shellCmd[i])
                        i = i + 1
                    else:
                        temp_shell_path = shell_path
                        print "\n=========================== Line No - ", i+1, "=========================="
                        logger.debug("\n========================== Line No - " +
                                     str((i + 1)) + "==========================\n")
                        print "\nName:", test_name[i]
                        logger.debug("\nName:" + test_name[i] + "\n")
                        '''new lines end'''

                        if option == 4:
                            if "EFI" in test_name[i]:
                                # if efi == 'Yes':
                                logger.debug(
                                    "Setting Shell Path as per EFI to the Package location")
                                temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,
                                                                               'Utilities_Packages/' + UTILITY_NAME + '/Utility/UEFI'))
                            else:
                                temp_shell_path = ""
                                logger.debug("Taking shell path as null")

                        if "downgrade" in test_name[i].lower():
                            logger.debug('Reading Downgrade Package Details')

                            if option == 4 or option == 7 or option == 5 or option == 8:
                                component = getFlow(test_name[i])

                            pkgName = config.get(
                                'PACKAGES', 'Downgrade' + component.upper())
                            act_pkgName = pkgName.split('/')[-1]
                            shellCmd[i] = shellCmd[i].replace(
                                '{}', act_pkgName)
                            logger.debug(
                                'Constructed Downgrade package command is : ' + shellCmd[i])
                            temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,
                                                                           'Utilities_Packages/Packages/Downgrade/' +
                                                                           pkgName.split('/')[0], ""))

                            '''
                            if "{}" in shellCmd[i]:
                                shellCmd[i] = shellCmd[i].replace('{}', config.get(UTILITY_NAME, component + 'DownPkg')).replace('\"', '')
                                logger.debug('Shell Cmd: ' + shellCmd[i])
                            
                            if option == 4:
                                temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,
                                                                           'Utilities_Packages/' + UTILITY_NAME + '/DowngradePkg/ALL'))
                                logger.debug('Shell Path: ' + temp_shell_path)
                            else:
                                temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + UTILITY_NAME + '/DowngradePkg',component.upper()))
                                logger.debug('Shell Path: ' + temp_shell_path)
                            '''

                        elif "upgrade" in test_name[i].lower():
                            # ToDo: need to check if this is required
                            component = getFlow(test_name[i])
                            logger.debug('Reading Upgrade Package Details')

                            '''

                            if option == 4 or option == 7:  # ToDO: remove this if criteria
                                component = getFlow(test_name[i])
                                
                            '''

                            # *if "{}" in shellCmd[i]:
                            # *    shellCmd[i] = shellCmd[i].replace('{}', config.get(UTILITY_NAME, component + 'UpdPkg')).replace('\"', '')
                            # *    logger.debug('Constructed Cmd: ' + shellCmd[i])
                            pkgName = config.get(
                                'PACKAGES', 'Upgrade'+component.upper())
                            act_pkgName = pkgName.split('/')[-1]
                            shellCmd[i] = shellCmd[i].replace(
                                '{}', act_pkgName)
                            logger.debug(
                                'Constructed Upgrade package command is : ' + shellCmd[i])
                            temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(
                                __file__), os.pardir, 'Utilities_Packages/Packages/Upgrade/' + pkgName.split('/')[0], ""))

                            '''

                            if option == 4:
                                temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,'Utilities_Packages/' + UTILITY_NAME + '/UpgradePkg/ALL',""))
                                logger.debug('Package Path: ' + temp_shell_path)
                            else:

                                temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,'Utilities_Packages/' + UTILITY_NAME + '/UpgradePkg',component.upper()))
                                logger.debug('Shell Path: ' + temp_shell_path)
                                
                            '''

                        elif "Install" in test_name[i]:
                            logger.debug(
                                "fetching utility name for installation")
                            # *temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/'+UTILITY_NAME+'/Installer'))
                            temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,
                                                                           'Utilities_Packages/Utilities/' + UTILITY_NAME))

                        elif "Input_files" in test_name[i]:
                            logger.debug(
                                "Moving required files from Host to SUT")
                            temp_shell_path = os.path.abspath(os.path.join(os.path.dirname(
                                __file__), os.pardir, 'Datafeed/' + 'InputFiles/' + UTILITY_NAME))

                        logger.debug(
                            'Initiating Trigger Shell IB with below details:')
                        logger.debug("\nShell Path: " + str(temp_shell_path) + "\nTest Name: " + str(test_name[i]) + "\nShell Cmd: " + str(shellCmd[i]) + "\nExp Out: " + str(
                            shell_expected_out[i]) + "\nComponent: " + str(component) + "\nWD Path: " + str(wd_path) + "\nOption: " + str(option))
                        result, message = trigger_shell_ib(
                            temp_shell_path, test_name[i], shellCmd[i], shell_expected_out[i], component, wd_path, option)
                        if "step" not in test_name[i].lower():
                            # write_txt(destination, test_name[i], result, message, i)
                            write_txt(
                                destination, test_name[i], shellCmd[i], result, message)
                        time.sleep(int(delay[i]))
                        i = i+1
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in " + file_input + \
            ".txt.\n\tPlease verify and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in " + file_input +
                     ".txt.\n\tPlease verify and re-run the Automation.\n")
