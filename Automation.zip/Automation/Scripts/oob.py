import ConfigParser
import subprocess,os
config = ConfigParser.ConfigParser()
#print("Entered OOB.py")
ip_config_path=os.path.abspath(os.path.join(os.path.dirname(__file__),os.pardir,'Datafeed','ipConfig.ini'))
config.read(ip_config_path)
#print(ip_config_path)


#function to extract required IPs for each group and segregate them into BMC and OS IPs
def iplist_extract():
    new_ip_list = []
    ip_data = config.get('IMSM', 'MSM_TestBed')
    ip_data = ip_data.split(",")
    for i in range(len(ip_data)):
        required_ip_list = []
        ip_group_name,ip_num = ip_data[i].split(":")
        group_ip_list = config.get('Groups_IP_List', ip_group_name)
        bmc_ip = group_ip_list.split(";",1)[0]
        os_ip_list = group_ip_list.split(";",1)[1].split(",")

        for j in range(int(ip_num)):
            required_ip_list.append(os_ip_list[j])

        required_ip_list.insert(0,ip_group_name)
        required_ip_list.insert(1, bmc_ip)

        new_ip_list.append(required_ip_list)
    # print new_ip_list [[platform], [bmcip]]
    return new_ip_list


# function to add Group names after checking its existance
def add_group(new_ip_list):
    group_name = []
    for i in range(len(new_ip_list)):
        group_name.append(new_ip_list[i][0])
    length = len(group_name)
    for i in range(length):
        if is_group(group_name[i]) is True:
            delete_group(group_name[i])
            add_group_name(group_name[i])
        else:
            #delete_group(group_name[i])
            add_group_name(group_name[i])
            
ism_dir_path = '/usr/local/ism/ism_scripts/'


#function to check if Group name exists
def is_group(group_name):
    p = subprocess.Popen('python ism_listGroups.pyc --ALL', cwd=ism_dir_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    output, error = p.communicate()
    #print output, error
    if group_name in str(output):
        return True
    else:
        return False

#function to delete Group
def delete_group(group_name):
    p = subprocess.Popen('python ism_deleteGroup.pyc -g'+ group_name, cwd=ism_dir_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    p.stdin.write(b'y\n')
    output, error = p.communicate()
    #print output, error
    if error == bytes(b''):
        return True
    else:
        return False


#function to add Groupname
def add_group_name(group_name):
    p = subprocess.Popen('python ism_addNewGroup.pyc -g'+ group_name, cwd=ism_dir_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    output, error = p.communicate()
    #print output, error
    if error == bytes(b''):
        return True
    else:
        return False


new_ip_list = iplist_extract()
add_group(new_ip_list)
print "Successfully added Groups"

