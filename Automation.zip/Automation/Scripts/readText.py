pathVariable = '/usr/local/ism/ism_scripts/SDPTool/Logfiles/10_223_244_64/custom_deploy_output.txt'
print("Reading from:", pathVariable)
fd = open(pathVariable)
outText = fd.read()
print(outText)
