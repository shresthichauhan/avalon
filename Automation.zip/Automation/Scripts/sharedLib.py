import datetime, os, tarfile, ConfigParser, time, glob, platform, shutil
from subprocess import Popen, PIPE
import subprocess, collections
import platform
from pkg_resources import file_ns_handler
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from logger import *
from Libraries.ssh import *
import re
import requests, json, sys
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

sut_IP = ''
sut_uname = ''
sut_pwd = ''
sut_IP_list = []

config = ConfigParser.ConfigParser()
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
config.read(config_path)

ipConfig_SharedLib = ConfigParser.ConfigParser()
ipConfig_path_SharedLib = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'ipConfig.ini'))
ipConfig_SharedLib.read(ipConfig_path_SharedLib)

sphConfig_SharedLib = ConfigParser.ConfigParser()
sphConfig_path_SharedLib = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'sphConfig.ini'))
sphConfig_SharedLib.read(sphConfig_path_SharedLib)

#Rakesh - Need to uncomment for Azure Scripts to work
#filepath = config.get('AZUREPS', 'AzureWD')

os_info = ''
TC_Name = ''
# to parse input into commands,outputs and errors
def read_txt(src, test_key):
    global os_info
    z, test_case_name, cmd, expected_out = [], [], [], []
    # resp_err = []
    f = open(src, "r")
    contents = f.readlines()
    os_info = test_key

    # To get test cases for environments specified
    found_type = False
    tc_list = []
    try:
        for line in contents:
            if ('<' + test_key + '>').lower() in line.lower():
                found_type = True
                continue
            if found_type:
                if ('</' + test_key + '>').lower() in line.lower():
                    break
                else:
                    tc_list.append(line)
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in input.txt.\n\tPlease verify <OS_name> and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in input.txt.\n\tPlease verify <OS_name> and re-run the Automation.\n")

    logger.debug(str(test_key) + " TC List: " + str(tc_list))
    contents = tc_list

    # To ignore a block of tests
    new_contents = []
    try:
        i, k = 0, 0
        flag = False
        while i < len(contents):
            if flag:
                logger.debug("Read Text value of k: " + str(k))
                i = k
                flag = False
            # i = i + 1
            if contents[i] == '$\n':
                for j in range(i, len(contents)):
                    if contents[j] == "$$\n" or contents[j] == "$$":
                        logger.debug("Yes")
                        k = j + 1
                        i = k
                        flag = True
                        break
            else:
                new_contents.append(contents[i])
            i = i + 1
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in input.txt.\n\tPlease verify placement of block comment symbols '$' and '$$' and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in input.txt.\n\tPlease verify placement of block comment symbols '$' and '$$' and re-run the Automation.\n")

    # print "NEW",new_contents
    contents = new_contents

    '''Code segment integrating delay requirement between test cases'''
    delay = []
    try:
        for i in range(len(contents)):
            if "delay" in contents[i] and "#" not in contents[i]:
                    contents[i-1] = contents[i-1] + ";" + contents[i].split('=')[1].strip('\r\n')
            else:
                    contents[i-1] = contents[i-1] + ";" + '0'
        for line in contents:
            if line[0] != "#" and line[0] != "\n":
                if "delay" not in line:
                    if line.strip():
                        z.append(line)
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in input.txt.\n\tPlease verify placement of comment symbol '#' and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in input.txt.\n\tPlease verify placement of comment symbol '#' and re-run the Automation.\n")

    '''code segment ends'''
    contents = z
    length = len(contents)
    for line in contents:
        test_case_name.append(line.split(';', 3)[0])
        cmd.append(line.split(';', 3)[1])
        expected_out.append(line.split(';', 3)[2].strip())
        delay.append(line.split(';', 3)[3].strip())

    f.close()
    return test_case_name, delay, cmd, expected_out, delay, length

# write timestamped result into date stamped file
# def write_txt(destination_path, test_case_name, result_compare, message, i):


def write_txt(destination_path, test_case_name, test_case_cmd, result_compare, message):
    try:
        datestamp = datetime.datetime.now().strftime("%y_%m_%d")
        timestamp = datetime.datetime.now().strftime("%y-%m-%d %H:%M:%S")
        destination = destination_path + "_output_" + datestamp + ".txt"
        message = message.replace('\n', '')

        if result_compare is True:
            test_output = "[" + timestamp + "]" + "; " + test_case_name + "-- ("+test_case_cmd+"); PASS; " + message
            logger.debug("\nTest Case: " +str(test_case_name)+ " == Test Result: PASS")
        elif result_compare is False:
            #*test_output = "[" + timestamp + "]" + "; " + test_case_name + "; FAIL; " + message
            test_output = "[" + timestamp + "]" + "; " + test_case_name + "-- ("+test_case_cmd+"); FAIL; " + message
            logger.debug("\nTest Case: " + str(test_case_name) + " == Test Result: FAIL")
        else:
            #*test_output = "[" + timestamp + "]" + "; " + test_case_name + "; FAIL; " + message
            test_output = "[" + timestamp + "]" + "; " + test_case_name + "-- ("+test_case_cmd+"); FAIL; " + message
            logger.debug("\nTest Case: " + str(test_case_name) + " == Test Result: " + str(result_compare))

        # print(test_output)
        f = open(destination, "a+")
        f.write(test_output + "\n")
        f.close()
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in writing the results. \n\tPlease verify and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in writing the results. \n\tPlease verify and re-run the Automation.\n")

def clean_up(result):
    if type(result) == list:
        # print "Initial:\n", result, type(result)
        if utility.lower() == "sysinfo":
            return result
        else:
            result = [line.decode("utf-8").strip(' \n\t') for line in result]
        # print "Final:\n", result
        return result
    else:
        # print "Initial:\n", result
        string = ''
        for line in result:
            result = line.decode("utf-8")

            for element in result:
                string += str(element)
        # print("string:\n", string)
        return string


# decision between output and error and comparison of output
def edit_shell_response(output, error, shell_expected_out, option):
    logger.debug("Editing Shell Response for any special characters")
    if error == bytes(b''):
        logger.debug("Bytes Processing")
        string = string_edit_output(str(output), option)
    else:
        logger.debug("Regular Processing")
        string = string_edit_error(str(error), option)

    logger.debug("\nExpected Output: \n" + str(shell_expected_out))
    logger.debug("\nTest Output : \n" + str(string))
    logger.debug("Calling Compare Strings")
    result = compare_string("", string, shell_expected_out)
     
    # print "Test Result: ", result
    # print("String", string)
    return result, string


# function to edit shell output
def string_edit_output(string, option):
    # print(string)
    if option is 1:
        # string = string.split("b\'")[1].split("(venv)")[0].replace("\\r\\n", " ").split(" ")[0].strip()
        # string = string.split("b\'")[1].replace("\\n", "\n").strip("\'")
        result = ''
        for element in string:
            result += str(element)
    elif option is 2:
        result = string.replace("\\n", "\n").strip("\\'")
    else:
        result = string

    # print("\nTest Output: \n")
    # print(result)
    #logger.debug("\nTest Output: \n" + result)
    return result


# function to edit shell error
def string_edit_error(string, option):
    if option is 1:
        logger.debug("\nError Output: \n" + string)
        # string = string.split("b\"")[1].replace("\\r\\n", " ").strip("\"").strip()
    elif option is 2:
        string = string.split(": ", 1)[1].replace("\\n", "").strip()
    result = ''
    for element in string:
        result += str(element)
    return result


# compare 2 strings or find a string in a string list
def compare_string(server, responses_cmd, contents_txt):
# def compare_string(responses_cmd, contents_txt):
    global sut_IP, sut_uname, sut_pwd
    global sut_IP_list
    retVal = False

    if utility.lower() == "sysinfo" or utility.lower() == "iflash32" or utility.lower() == "fwpiaupd" or utility.lower() == "selviewer":
        logger.debug("Compare String for Sysinfo identified, skipping Errors Block")
    else:
        # changes for checking error messages
        if "errChk>" in contents_txt:
            expChecks = contents_txt.split(',')
            for x in range(len(expChecks)):
                checkType = expChecks[x].split('>')
                if checkType[0] == 'errChk':
                    if checkType[1] in responses_cmd:
                        retVal = True
                    else:
                        logger.debug("Errors observed in the terminal output")
                        retVal = False
        else:
            # ---------------------------------------------
            logger.debug("Non Sysinfo utility, checking for Errors Block")
            errors_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'Errors.txt'))
            with open(errors_path) as f:
            #with open('Errors.txt') as f:
			#with open(errors_path) as f:
                lines = f.readlines()
            for i in lines:
                #logger.debug('Validating Output for : =========>' + i)
                #if i in responses_cmd:
                if re.search(i.strip(), responses_cmd):
                    logger.debug('Actual Value: ' + responses_cmd)
                    logger.debug('$$$$$$$$$$ Error Found $$$$$$$$$$')
                    logger.debug('Error keyword Found : ' + str(i.strip()))
                    return False
                else:
                    #logger.debug('Actual Value: ' + responses_cmd)
                    logger.debug('********** No Error Found **********')


    #logger.debug('Expected Value: ' + responses_cmd)

    if utility == "SDP" or utility == "IMSM":
        logger.debug("SDP/IMSM Expected Output Modification")
        sdpLog = ipConfig_SharedLib.get(utility, "SUT_Log")
        if "{}" in contents_txt:
            contents_txt = contents_txt.replace('{}', sdpLog).replace('\"', '')
            logger.debug('Expected Output Before Split: ' + contents_txt)

    expChecks = contents_txt.split(',')
    for x in range(len(expChecks)):
        checkType = expChecks[x].split('>')
        if checkType[0] == 'msg':
            #logger.debug("Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
            if checkType[1].lower().lstrip('0') in responses_cmd.lower().lstrip('0'):
                logger.debug("MSG Found")
                retVal = True
                # return True
            else:
                logger.debug(
                    "MSG Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
                logger.debug("  ")
                return False
            
        if checkType[0] == 'msgCS':
            #logger.debug("Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
            if checkType[1] in responses_cmd:
                logger.debug("MSG Found")
                retVal = True
                # return True
            else:
                logger.debug("msgCS Comparing==> " + checkType[1].lstrip('0') + ' == ' + responses_cmd.lstrip('0'))
                logger.debug("MSG was not Found")
                return False

        if checkType[0] == 'msgCSabsent':
            #logger.debug("Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
            if checkType[1] in responses_cmd:
                logger.debug("msgCS expected to be absent, but MSG Found")
                retVal = False
                # return True
            else:
                logger.debug("msgCS Comparing==> " + checkType[1].lstrip('0') + ' == ' + responses_cmd.lstrip('0'))
                logger.debug("MSG was not Found, as expected")
                return True
            
        if checkType[0] == 'absent':
            #logger.debug("Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
            if checkType[1].lower().lstrip('0') not in responses_cmd.lower().lstrip('0'):
                logger.debug("Absent MSG not Found")
                retVal = True
                # return True
            else:
                logger.debug(
                    "Absent Comparing==> " + checkType[1].lower().lstrip('0') + ' == ' + responses_cmd.lower().lstrip('0'))
                logger.debug("Absent MSG Found")
                return False

        if checkType[0] == 'file':
            # print("File: " + checkType[1])
            file1 = checkType[1]
            print "file1--->" + checkType[1]
            retVal = checkFileExists(server, checkType[1])

        if checkType[0] == 'lfile':
            if 'azureps' in utility.lower():
                retVal = azure_file_search(checkType[0],checkType[1])
            else:
                if os.path.isfile(checkType[1]):
                    logger.debug("lfile found successfully")
                    file1 = checkType[1]
                    file3 = checkType[1]
                    retVal = True
                else:
                    logger.debug("lfile was not found")
                    return False

        if checkType[0] == 'lfileDeleted':
            if 'azureps' in utility.lower():
                retVal = azure_file_search(checkType[0],checkType[1])
                if retVal == True:
                    return False
                else:
                    retVal = True
            else:
                if os.path.isfile(checkType[1]):
                    logger.debug("lfile is not deleted")
                    return False
                else:
                    logger.debug("lfile deleted successfully")
                    retVal = True

        if checkType[0] == 'dir':
            # print("<File: >" + checkType[1])
            if os.path.isdir(checkType[1]):
                retVal = True
            else:
                return False

        if checkType[0] == 'dirDeleted':
            # print("<File: >" + checkType[1])
            if os.path.isdir(checkType[1]) == False:
                logger.debug("Directory is no present as expected" + str(checkType[1]))
                retVal = True
            else:
                logger.debug("Directory is present but not expected" + str(checkType[1]))
                return False

        if checkType[0] == 'verify':
            if "azureps" in utility.lower() and "list" in checkType[1]:
                for ip in sut_IP_list:
                    if ip in responses_cmd:
                        retVal = True
                    else:
                        return False
            if "imsm" in utility.lower() and "version" in checkType[1]:
                output = ism_version()
                for item in output:
                    if item.lower() in responses_cmd.lower():
                        retVal = True
                    else:
                        return False
            
        if checkType[0] == 'verify_ipmi':
            if 'sph' in checkType[1]:
                retVal = ipmiParser(server, checkType[1],responses_cmd)
            else:
                cmd = checkType[1]
                if sut_IP_list:
                    # print "Multiple IP list: ",sut_IP_list
                    for ip in sut_IP_list:
                        sut_IP = ip
                        retVal = ipmi_verify(cmd,responses_cmd)
                else:
                    # print "Single sut_IP: ",sut_IP
                    retVal = ipmi_verify(cmd,responses_cmd)

        if checkType[0] == 'verEWS':
            loadBMCConsole()
            with open(r"C:\temp\bmc_output.txt") as f:
                lines = f.readlines()
            for x in lines:
                print lines.index(x), x
                if x in responses_cmd:
                    retVal = True
                else:
                    return False

        if checkType[0] == 'bmcRedFish':
            if "biosKnob" in checkType[1]:
                fetchKnob = "/redfish/v1/Systems/............/Bios"
                fetchVal = checkType[1].split('-')
                logger.debug("URI: "+str(fetchKnob))
                logger.debug("BIOS_Knob: "+str(fetchVal[1]))
            retVal = getKnobVal(fetchKnob, fetchVal[1])

        if checkType[0] == 'search_file':
            # print("File: " + checkType[1])
            file3 = checkType[1]
            # print "file1--->" + file3

        if checkType[0] == 'search_msg':
            # print("File: " + checkType[1])
            s_msg = checkType[1]
            # print "s_msg" + checkType[1]
            retVal = search_str_in_file(server, s_msg, file3)

        if checkType[0] == 'lsearch_msg':
            s_msg = checkType[1]
            # print "s_msg" + checkType[1]
            retVal = search_str_in_lfile(s_msg, file3)

        if checkType[0] == 'lsearch_msg_occurrence':
            s_msg = checkType[1].split("=")[0]
            s_msg_count = checkType[1].split("=")[1]
            # print "s_msg" + checkType[1]
            retVal = search_str_occurrence_in_lfile(s_msg, s_msg_count, file3)

        if checkType[0] == 'lsearch_absent':
            s_msg = checkType[1]
            # print "s_msg" + checkType[1]
            retVal = search_str_in_lfile(s_msg, file3)
            if retVal == "False":
                retVal = True

        if checkType[0] == 'compareFiles':
            # print("File: " + checkType[1])
            file2 = checkType[1]
            print "file2--->" + checkType[1]
            # if os.path.isfile(checkType[1]):
            retVal = compare_files(server, file1, file2)

        if checkType[0] == 'verify_H2B':
            logger.debug("Matching H2B with List")
            retVal = azure_H2B_sync(responses_cmd)

        if checkType[0] == 'verify_sysinfo':
            logger.debug("Verification of SysInfo Details")
            logger.debug("Matching output with SYSInfoLog")
            retVal = sysinfo_search(responses_cmd, checkType[1])

        if checkType[0] == 'compare_block':
            if checkType[1] == 'tmp_file_creation_details':
                logger.debug("file copying at Host")
                executeCommand('', "cp -rf /usr/local/log/SDPTool/Logfiles/" + ipConfig_SharedLib.get(utility,'EFI_IP').replace('.', '_') + "/custom_deploy_details.txt" + "  /root/Desktop/")
                retVal = True
            elif checkType[1] == 'tmp_file_creation_output':
                executeCommand('', "cp -rf /usr/local/log/SDPTool/Logfiles/" + ipConfig_SharedLib.get(utility,'EFI_IP').replace('.', '_') + "/custom_deploy_output.txt" + "  /root/Desktop/")
                retVal = True
            else:
                compare_block = ConfigParser.ConfigParser()
                compare_block_path = os.path.abspath(
                    os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'compare_block.ini'))

                compare_block.read(compare_block_path)

                compare_operation = compare_block.get(utility, checkType[1])
                comp_string1 = compare_operation.split('||')[0].split(']')

                comp_string2 = compare_operation.split('||')[1].split(']')

                file1_path = re.findall("\[(.*?)\]", compare_operation.split('||')[0])
                extra_character1 = re.findall("\((.*?)\)", compare_operation.split('||')[0])[0]
                file2_path = re.findall("\[(.*?)\]", compare_operation.split('||')[1])
                extra_character2 = re.findall("\((.*?)\)", compare_operation.split('||')[1])[0]

                file_data1 = readfile(file1_path[0])
                file_data2 = readfile(file2_path[0])

                comp_string_ver1 = re.findall(comp_string1[1] + r"[\s:.]+([./:A-Za-z0-9]+)", file_data1)
                comp_string_ver2 = re.findall(comp_string2[1] + r"[\s:.]+([./:A-Za-z0-9]+)", file_data2)

                if ((extra_character1.lower() + comp_string_ver1[0].lower()) == (extra_character2.lower() + comp_string_ver2[0].lower())):
                    print("matching string found")
                    retVal = "True"
                else:
                    print("failed to find the matching string")

    return retVal

def azure_file_search(key,file_path):
    lfile_list = []
    if "multiple" in file_path.lower() or "%" in file_path.lower():

        temp_IP_list = []
        if "multipleIP" in file_path:
            file_path = file_path.replace("{multipleIP}",ipConfig_SharedLib.get("AZUREPS","multipleIP"))
        if "multipleHost" in file_path:
            file_path = file_path.replace("{multipleHost}",ipConfig_SharedLib.get("AZUREPS","multipleHost"))
        path = find("HostToBMC.txt",file_path)
        with open(path) as f:
            HTB_contents = f.readlines()
        logger.debug("Resolved lfile path: " + str(file_path))        
        if "," in file_path.split("\\%")[-1].split("_")[0]:
            IP_list = file_path.split("\\%")[-1].split("_")[0].split(",")
            for item in IP_list:
                if '.' in item.lower():
                    temp_IP_list.append(item)
                else:
                    for line in HTB_contents:
                        if item.lower() in line.lower():
                            temp_IP_list.append(line.split(",")[0])
        else:
            IP = str(file_path.split("\\%")[-1].split("_")[0]).split('.ini')[0]
            if '.' not in IP.lower():
                for i in HTB_contents:
                    if IP.lower() in i.lower():
                        temp_IP_list.append(i.split(",")[0])
            else:
                temp_IP_list.append(IP)
        IP_list = temp_IP_list
        logger.debug("IP list: " + str(IP_list))
        for ip in IP_list:
            if "debuglog" in file_path.lower():
                ip_path = "\\".join(file_path.split("\\")[:-1]) + "\\%" + ip + "_" + file_path.split("\\")[-1].split("_")[1]
            else:
                ip_path = "\\".join(file_path.split("\\")[:-1]) + "\\%" + file_path.split("\\")[-1]
            lfile_list.append(ip_path)
    else:
        lfile_list.append(file_path)
    logger.debug("Files to be searched locally :" + str(lfile_list))
    #print lfile_list
    for ip_path in lfile_list:
        logger.debug("File being searched: " + ip_path)
        if "%" in ip_path:
            file_name = ip_path.split("%")[1]
            dir_path = ip_path.split("%")[0]
            all_subdirs = os.listdir(dir_path)
            for item in all_subdirs:
                if file_name in item:
                    logger.debug("File in: "+ dir_path+file_name)
                    retVal = True
        elif os.path.isfile(ip_path):
            logger.debug("lfile Found!!!")
            retVal = True
        else:
            logger.debug("lfile was not Found")
            return False

    return retVal

def azure_H2B_sync(responses_cmd):
    iterator = 0
    retVal = False
    #config = ConfigParser.ConfigParser()
    #config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
    #config.read(config_path)
    filepath = config.get('AZUREPS', 'AzureWD')
    filename = r'' + filepath + 'HostToBMC.txt'
    logger.debug("H2B file is located at : " + filename)
    with open(filename) as f:
        content = f.readlines()
        logger.debug("H2B content: " + str(content))
    for line in content:
        val = line.split(',')
        for i in val:
            iterator = iterator + 1
            if iterator == 3:
                logger.debug("Ignoring Search for '"+ i + "' in =>"+ str(responses_cmd))
                iterator = 0
                continue
            elif iterator < 3:
                logger.debug("Searching '"+ i + "' in =>"+ str(responses_cmd))
                if i in responses_cmd:
                    logger.debug(" Found ")
                    retVal = True
                else:
                    logger.debug(" Not Found ")
                    return False
    return retVal

def create_file_text(file_path, file_type, text, mode):
    try:
        os.path.join(file_path, file_type)
        file = open(file_path+file_type, mode)
        logger.debug("File: " + str(file))
        file.write(text)
        #logger.debug(("Writing Text: " + str(text)))
        file.close()
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in creating the file at " + str(file) + "\n\tPlease verify and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in creating the file at " + str(file) + "\n\tPlease verify and re-run the Automation.\n")

def readfile(file_path):
    try:
        #print("Readfile:")
        #print(file_path)
        logger.debug("Readfile: " + str(file_path))
        fd = open(file_path, "r")
        #outText = fd.read()
        outText = (fd.read()).replace('\x00', "")
        #outText = clean_up(outText)
        return outText
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in reading the file at " + str(file_path) + "\n\tPlease verify and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in reading the file at " + str(file_path) + "\n\tPlease verify and re-run the Automation.\n")

def createTar(path):
    #ToDo: Ambala - add check on what type of an OS we are trigger from
    # and change the below path accordingly
    #tarName = os.path.abspath(os.path.join(os.path.dirname(__file__).split("/",1)[0],"/","temp","temp"+".tar.gz"))


    if platform.system().lower() == "windows":
        tarName = r"C:\temp\temp.tar.gz"
    else:
        tarName = r"/tmp/temp.tar.gz"

    logger.info('Creating ' + tarName)
    with tarfile.open(tarName, 'w:gz') as tar:
        tar.add(path, arcname=os.path.basename(path))

    return tarName

def createRemoteTar(server, path):
    try:
        tarName = r"/root/temp.tar.gz"
        logger.info("Creating tar file in remote system " +tarName+ " at location: " + str(path))
        #server.execute(tarfile.open(tarName, 'w:gz').add(path, arcname=os.path.basename(path)))
        server.execute(r'tar -czvf temp.tar.gz LogFiles')
    except Exception, e:
        logger.debug('Exception: ' + str(e))

    return tarName


# Ping the host and check if the server is up and running
def ping(host):
    osVariable = platform.system()
    logger.debug("Pinging Machine: " + str(host))
    if osVariable == "Windows":
        toping = Popen(['ping', '-n', '1', host], stdout=PIPE)
    else:
        toping = Popen(['ping', '-c', '1', host], stdout=PIPE)

    # if linux_os.lower() == "yes":
    #    toping = Popen(['ping', '-n', '-c 1', host], stdout=PIPE)
    # else:

    output = toping.communicate()[0]
    return toping.returncode

def loginToBMC():
    SUT = ipConfig_SharedLib.get('BMC', 'SUT')
    usrName = ipConfig_SharedLib.get('BMC', 'efiUsrName')
    usrPwd = ipConfig_SharedLib.get('BMC', 'efiUsrPwd')

    driverPath = os.path.abspath(os.path.join(os.path.dirname(__file__), 'Libraries','webDrivers', 'chromedriver.exe'))
    driver = webdriver.Chrome(driverPath)
    # driver = webdriver.Chrome(r"C:\Users\dsrakes\Documents\Rakesh\DCG\Utilities\A\GitClone\26Sep\deg_pid_bios_bdc_utilities-server_bios_utilities_automation\Automation\Scripts\Libraries\webDrivers\chromedriver.exe")
    url = "https://"+SUT
    driver.get(url)
    elem = driver.find_element_by_name("name")
    elem.send_keys(usrName)
    elem = driver.find_element_by_name("pwd")
    elem.send_keys(usrPwd)
    elem.send_keys(Keys.RETURN)
    time.sleep(5)
    return driver

def loadBMCConsole():
    driver = loginToBMC()
    bmcSummary = {}
    outerFrame = driver.find_elements_by_tag_name('frame')[0]
    driver.switch_to_frame(outerFrame)
    innerFrame = driver.find_elements_by_id('frame_main')[0]
    driver.switch_to_frame(innerFrame)

    label = driver.find_element_by_id('host_pwr_st_label').text
    value = driver.find_element_by_id('host_pwr_st').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('rmm_key_module_label').text
    value = driver.find_element_by_id('rmm_key_status').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('dev_ave_label').text
    value = driver.find_element_by_id('dev_ave').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('build_time_label').text
    value = driver.find_element_by_id('build_time').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('bios_id_label').text
    value = driver.find_element_by_id('bios_id').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('fw_rev_label').text
    value = driver.find_element_by_id('fw_rev').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('back_fw_label').text
    value = driver.find_element_by_id('backup_fw_rev').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('boot_fw_label').text
    value = driver.find_element_by_id('boot_fw_rev').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('sdr_pkg_rev_label').text
    value = driver.find_element_by_id('sdr_rev').text
    bmcSummary[label] = value

    label = driver.find_element_by_id('mw_fw_rev_label').text
    value = driver.find_element_by_id('me_rev').text
    bmcSummary[label] = value

    driver.close()

    timestamp = datetime.datetime.now().strftime("%y_%m_%d")
    destination = r"C:\temp\bmc_output.txt"
    f = open(destination, "w")
    for label in bmcSummary:
        f.write(label + bmcSummary[label] + "\n")
    f.close()
    return bmcSummary

def getKnobVal(fetchKnob, fetchVal):
    try:
        #bmc_ip = sys.argv[1]
        logger.debug("Initiate BMC Redfish Query")
        bmc_ip = ipConfig_SharedLib.get(utility,'EFI_IP')
        username = ipConfig_SharedLib.get(utility,'efiUsrName')
        passwd = ipConfig_SharedLib.get(utility,'efiUsrPwd')
        redfish_uri = fetchKnob
        logger.debug("BMC_Redfish_Query: "+ redfish_uri)

    except:
        print("FAIL: Usage: <ScriptName> <BMC IP> <USERNAME> <PASSWORD> <REDFISH_URL> \n")
        print("Ex: python %s 10.66.128.45 root 0penBmc /redfish/v1/Managers\n" % (sys.argv[0]))
        sys.exit()

    url = 'https://%s%s' % (bmc_ip, redfish_uri)
    response = requests.get(url, verify=False, auth=(username, passwd))

    with open('response.txt', 'w') as f:
        print>> f, (json.dumps(response.json(), indent=2))
        logger.debug(str((json.dumps(response.json(), indent=2))))
        if fetchVal in (json.dumps(response.json(), indent=2)):
            logger.debug("[["+str(fetchVal)+"]] - Present")
            return True
        else:
            logger.debug("[[" + str(fetchVal) + "]] - Absent")
            return False

def getFlow(testcase):
    try:
        if 'bios_upgrade' in testcase.lower() or 'bios_downgrade' in testcase.lower():
            return 'bios'
        elif 'me_upgrade' in testcase.lower() or 'me_downgrade' in testcase.lower():
            return 'me'
        elif 'bmc_upgrade' in testcase.lower() or 'bmc_downgrade' in testcase.lower():
            return 'bmc'
        elif 'frusdr_upgrade' in testcase.lower() or 'frusdr_downgrade' in testcase.lower() or 'frusdr_only_upgrade' in testcase.lower() or 'frusdr_only_downgrade' in testcase.lower():
            return 'frusdr'
        elif 'all_upgrade' in testcase.lower() or 'all_change_upgrade' in testcase.lower() or 'all_downgrade' in testcase.lower():
            return 'all'
        elif 'fd_upgrade' in testcase.lower() or 'fd_downgrade' in testcase.lower():
            return 'fd'
    except:
        logger.debug("Exception occurred")

def getVersion(testcase):
    if 'backup_bios_upgrade' in testcase.lower() or 'backup_bios_downgrade' in testcase.lower():
        return 'Backup BIOS Version'
        # Renamed Secondary to Backup, if fails for any utiltiy, add a new if
    if 'bios_upgrade' in testcase.lower() or 'bios_downgrade' in testcase.lower():
        return 'Primary BIOS Version'
    elif 'me_upgrade' in testcase.lower() or 'me_downgrade' in testcase.lower():
        return 'ME Firmware Revision'
    elif 'bmc_upgrade' in testcase.lower() or 'bmc_downgrade' in testcase.lower():
        return 'BMC Firmware Revision'
    elif 'frusdr_upgrade' in testcase.lower() or 'frusdr_downgrade' in testcase.lower() or 'frusdr_only_upgrade' in testcase.lower() or 'frusdr_only_downgrade' in testcase.lower():
        return 'frusdr'
    elif 'all_upgrade' in testcase.lower() or 'all_downgrade' in testcase.lower():
        return 'all'


# Try connecting to the provided host
def connectToHost(SUT):
    try:
        attempt = 0
        iterFlag = 0
        while attempt < 10 and iterFlag < 3:
            logger.debug("Attempting ping: #" +str(attempt))
            if ping(SUT['ip']) == 0:
                logger.debug(SUT['ip'] + ' is up and running')
                logger.debug('[Connecting to ' + SUT['ip'] + ']')
                server = Connection(host=SUT['ip'], username=SUT['usrName'], password=SUT['usrPwd'])
                logger.info('Connected to ' + SUT['usrName'] + '@' + SUT['ip'])
                return server
            else:
                logger.debug("Waiting for 60 seconds")
                logger.debug("Attempt count " + str(attempt))
                time.sleep(60)
                attempt += 1
            if attempt == 10 and iterFlag < 3:
                logger.debug("Resetting the server ")
                reset_ping = bmc_info("power reset")
                iterFlag += 1
                attempt = 0
            else:
                logger.debug("Reset Server Counter: " + str(iterFlag))
        if iterFlag == 3:
            logger.debug("Retried for max. 3 times and it failed.")
    except Exception, e:
        logger.debug("Unable to connect to: "+ SUT['ip'] + ", Exception: " + str(e))


# Execute the provided command in the remote machine and return the cleaned result
def executeCommand(server, cmd):
    logger.info('Executing the command : ' + cmd)
    if server == "":
        process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
        result, error = process.communicate()
    else:
        result = server.execute(cmd)
    result = clean_up(result)
    logger.debug('[[[[Result]]]] : ' + "".join(result))
    return result


# Checks if a file or directory actually exists or not. Absolute path needs to be given
def checkFileExists(server, pkgName):
    # if linux_os == 'Yes':
    if os_info == 'LINUX':
        command = 'ls' + " " + pkgName
    # elif win_os == 'Yes':
    elif os_info == 'WINDOWS':
        command = 'dir ' + pkgName

    logger.debug("Command populated: " + str(command))
    result = executeCommand(server, command)
    result = "".join(result)
    if "No such file or directory" in result or "file not found" in result.lower():
        return False
    else:
        return True


# compare two files and gives the result in boolean
def compare_files(server, file1, file2):
    cmd = 'cmp ' + file1 + ' ' + file2
    # print cmd
    # Added by Nandan
    if server == "":
        process = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE, shell=True)
        result, error = process.communicate()
    else:
        result = executeCommand(server, cmd)
    result = "".join(result)
    print result
    if "differ" in result:
        return False
    elif "No such file or directory" in result:
        return False
    else:
        return True


# compare string in a SUT side file
# TODO_Rachana: Make this compatible on Windows as well
def search_str_in_file(server, msg, file1):
    # if linux_os == 'Yes':
    if os_info == 'LINUX':
        cmd = 'cat ' + file1
    # elif win_os == 'Yes':
    elif os_info == 'WINDOWS':
        cmd = 'more ' + file1
    print cmd
    logger.debug("Search Command: " + str(cmd))
    result = executeCommand(server, cmd)
    result = "".join(result)
    msg = "".join(msg)
    print result
    if msg in result:
        return True
    else:
        return False


def getCFG(testcase):
    executable = ""
    logger.debug("Get the String to be written into edit.cfg")

    if 'bios_upgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg'))
        logger.debug("Returning BIOS Upgrade string: " + executable)
        # return executable

    elif 'bios_downgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosDownPkgCfg'))
        logger.debug("Returning BIOS Downgrade string: " + executable)
        # return executable

    if 'biosbackup_upgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + " UpdateBackupBios")
        logger.debug("Returning BIOS Upgrade string: " + executable)
        # return executable

    elif 'biosbackup_downgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosDownPkgCfg') + " UpdateBackupBios")
        logger.debug("Returning BIOS Downgrade string: " + executable)

    elif 'upgrade_nvram' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + " UpdateNvram")
        logger.debug("Returning BIOS nvram string: " + executable)

    elif 'bmc_upgrade' in testcase.lower():
        executable = str('FWDNAME ' + config.get('OFU', 'bmcUpdPkgCfg') + ' filetype=fwimg')
        logger.debug("Returning BMC Upgrade string: " + executable)
        return executable

    elif 'bmc_downgrade' in testcase.lower():
        executable = str('FWDNAME ' + config.get('OFU', 'bmcDownPkgCfg') + ' filetype=fwimg')
        logger.debug("Returning BMC Downgrade string: " + executable)
        # return executable

    elif 'frusdr_upgrade' in testcase.lower():
        executable = str('CFGNAME ' + config.get('OFU', 'frusdrUpdCfg'))
        logger.debug("Returning FRUSDR Upgrade string: " + executable)
        # return executable

    elif 'frusdr_downgrade' in testcase.lower():
        executable = str('CFGNAME ' + config.get('OFU', 'frusdrDownPkgCfg'))
        logger.debug("Returning FRUSDR Downgrade string: " + executable)
        # return executable

    elif 'frusdr_only_upgrade' in testcase.lower():
        executable = str('SDRNAME ' + config.get('OFU', 'sdrOnlyUpdCfg') + ',FRUNAME ' + config.get('OFU', 'fruOnlyUpdCfg'))
        logger.debug("Returning FRU and SDR Upgrade string: " + executable)
        # return executable

    elif 'me_upgrade' in testcase.lower():
        executable = str('IMENAME ' + config.get('OFU', 'meUpdCfg'))
        logger.debug("Returning ME Upgrade string: " + executable)
        # return executable

    elif 'me_downgrade' in testcase.lower():
        executable = str('IMENAME ' + config.get('OFU', 'meDownPkgCfg'))
        logger.debug("Returning ME Downgrade string: " + executable)
        # return executable

    elif 'updateall_upgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcUpdPkgCfg') + ' filetype=fwimg' + ',CFGNAME ' + config.get('OFU', 'frusdrUpdCfg') + ',IMENAME ' + config.get('OFU', 'meUpdCfg'))
        # executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcUpdPkgCfg') + ',CFGNAME ' + config.get('OFU', 'frusdrUpdCfg') + ',meUpdCfg ' + config.get('OFU', 'meUpdCfg'))
        logger.debug("Returning All Upgrade string: " + executable)
        # return executable

    elif 'updateall_change_upgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcUpdPkgCfg') + ' filetype=fwimg' + ',IMENAME ' + config.get('OFU', 'meUpdCfg') + ',CFGNAME ' + config.get('OFU', 'frusdrUpdCfg'))
        # executable = str('BIOSNAME ' + config.get('OFU', 'biosUpdPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcUpdPkgCfg') + ',CFGNAME ' + config.get('OFU', 'frusdrUpdCfg') + ',meUpdCfg ' + config.get('OFU', 'meUpdCfg'))
        logger.debug("Returning All Upgrade string: " + executable)
        # return executable

    elif 'updateall_downgrade' in testcase.lower():
        executable = str('BIOSNAME ' + config.get('OFU', 'biosDownPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcDownPkgCfg') + ' filetype=fwimg' + ',CFGNAME ' + config.get('OFU', 'frusdrDownPkgCfg') + ',IMENAME ' + config.get('OFU', 'meDownPkgCfg'))
        # executable = str('BIOSNAME ' + config.get('OFU', 'biosDownPkgCfg') + ',FWDNAME ' + config.get('OFU','bmcDownPkgCfg') + ',CFGNAME ' + config.get('OFU', 'frusdrDownPkgCfg') + ',IMENAME ' + config.get('OFU', 'meDownPkgCfg'))
        logger.debug("Returning All Downgrade string: " + executable)
        # return executable

    logger.debug("Returning: " +executable)
    return executable


def search_str_in_lfile(msg, file1):
    f = open(file1,"r")
    contents = (f.read()).replace('\x00', "")
    lfile =str(contents)
    logger.debug("search_str_in_lfile: " + lfile)
    if msg in lfile:
        return True
    else:
        return False
    f.close()

def search_str_occurrence_in_lfile(s_msg, s_msg_count, file3):
    try:
        logger.debug("Reading file " +str(file3)+ " for occurrence check")
        with open(file3) as infile:
            counts = collections.Counter(l.strip() for l in infile)
        for line, count in counts.most_common():
            logger.debug("Occurrence_Check: " +str(line)+"=="+str(count))
            logger.debug("Message being verified is: " +str(s_msg))
            #print line, count
            if str(line).replace(" ","") == str(s_msg).replace(" ",""):
                logger.debug("Message found checking for occurrence count" + str(line))
                if int(s_msg_count) == count:
                    logger.debug("Line occurrence count matched" + str(line) + "=" +str(count))
                    return True
                else:
                    logger.debug("Line occurrence count did not match" + str(line) + "=" + str(count))
                    return False
            else:
                logger.debug("Next iteration: " +str(count))
    except Exception, e:
        logger.debug('Exception: ' + str(e))
        print "\n\033[91mError :\tError in occurrence check.\n\tPlease verify and re-run the Automation.\033[00m\n"
        logger.debug("\n\nError :\tError in occurrence check.\n\tPlease verify and re-run the Automation.\n")

def find(name, path):
    for root, dirs, files in os.walk(path):
        if name in files:
            return os.path.join(root, name)


def find_folder_file(name, folder, path):
    for root, dirs, files in os.walk(path):
        for filename in files:
            if name in filename:
                if ("\\"+folder+"\\") in os.path.join(root, filename):
                    return os.path.join(root, filename)


# -------------------------------------------------IPMI Verification Section--------------------------------------------
def ipmi_verify(key, responses_cmd):
    retVal = False
    output = ""
    
    if "system information" in key.lower():
        output = sys_info_bmc()
        # print output
        for item in output:
            if type(item) == list:
                for line in item:
                    if line.lower() in responses_cmd.lower():
                        retVal = True
                        # print "True"
                        break
                    else:
                        # print "False"
                        retVal = False
            else:
                if item.lower() in responses_cmd.lower():
                    # print "True"
                    retVal = True
                else:
                    # print "False"
                    return False
    # imsm version moved to verify in compare strings
    # below elif block is redundant if used in verify and can be removed later
    elif "imsm version" in key.lower():
        output= ism_version()
        for item in output:
            if item.lower() in responses_cmd.lower():
                retVal = True
            else:
                return False
    else:
        cmd_keys = ["bios","lan","fru","sensor","led status","power status","baseboard","backplane","power supply"]
        for item in cmd_keys:
            if item in key:
                logger.debug("BMC component being verified: " + str(item))
                output=bmc_info(item)
        # print output
        if type(output) == list:
            #logger.debug("not a list")
            for line in output:
                if line.lower() in responses_cmd.lower():
                    retVal = True
                    # print "True"
                    break
                else:
                    # print "False"
                    retVal = False
        else:
            #logger.debug("not a list")
            if output.lower() in responses_cmd.lower():
                # print "True"
                retVal = True
            else:
                # print "False"
                return False
    return retVal

def ipmiParser(server, key, cmdOutput):
    try:
        output = ""
        ipmiCmd = key.split('%')
        decodeType = ipmiCmd[1]
        logger.debug("Hex Values: " + str(cmdOutput))
        logger.debug("Decoding Type: " + str(ipmiCmd[1]))
        logger.debug("Decoding Length: " + str(ipmiCmd[2]))
        logger.debug("Expected output: " + str(ipmiCmd[3]))
        cmdOutput = cmdOutput.strip().split()
        logger.debug("Fine tuned raw output: " + str(cmdOutput))
        #completeOutput = "".join(cmdOutput).decode(decodeType)
        #logger.debug("Complete Translation is: " + str(completeOutput))

        #sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        if 'none' in str(ipmiCmd[1]).lower() and 'map' not in str(ipmiCmd[3]).lower():
            output = ""
            if ':' in str(ipmiCmd[2]):
                logger.debug("Getting range of list items")
                varCount = len(ipmiCmd[2].split(':'))
                varVal = ipmiCmd[2].split(':')
                logger.debug("Total length of list after split is: " + str(varCount))
                logger.debug("Total list items :" + str(varVal))
                for i in range(varCount):
                    j = int(varVal[i])
                    if "NNP I-1000 PCIe Vendor ID : 0x" in str(ipmiCmd[3]):
                        logger.debug("Vendor ID with concatination")
                        output = output + cmdOutput[j]
                    elif "NNP I-1000 Firmware Version" in str(ipmiCmd[3]):
                        output = output + cmdOutput[j] +"."
                    else:
                        logger.debug("Appending the bytes")
                        output = output + cmdOutput[j] +" "
            else:
                output = cmdOutput[int(ipmiCmd[2])]
            logger.debug("The byte(s) retrieved is: " + str(output))
        # sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        elif 'dec' in str(ipmiCmd[1]):
            output = int(cmdOutput[int(ipmiCmd[2])], 16)
        # sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        else:
            logger.debug("Going into additional checks")
            if  'map' not in str(ipmiCmd[3]).lower():
                if 'all' not in str(ipmiCmd[2]).lower():
                    if ':' in str(ipmiCmd[2]):
                        logger.debug("Reading range of values")
                        integerVal = ipmiCmd[2].split(':')
                        logger.debug("IntegerVal: " + str(integerVal[0]))
                        logger.debug("IntegerVal2: " + str(integerVal[1]))
                        output = "".join(cmdOutput[int(integerVal[0]):int(integerVal[1])]).decode(decodeType)
                    else:
                        logger.debug("Single byte translation")
                        output = "".join(cmdOutput[int(ipmiCmd[2])]).decode(decodeType)
                else:
                    logger.debug("Parsing the complete IPMI output")
                    output = "".join(cmdOutput).decode(decodeType)

        logger.debug("Processed output: " + str(output))

        # sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        if 'none' not in str(ipmiCmd[3]) and 'check' not in str(ipmiCmd[3]) and 'map' not in str(ipmiCmd[3]).lower():
            if str(ipmiCmd[3]) in str(output) or int(ipmiCmd[3]) == int(output):
                logger.debug("Processed IPMI Output: [" + str(output) + "] == [" + str(ipmiCmd[3]) + "] Expected Output")
                print "\nProcessed IPMI Output: [" + str(output) + "] == [" + str(ipmiCmd[3]) + "] Expected Output\n"
                return True
            else:
                logger.debug("Processed IPMI Output: [" + str(output) + "] != [" + str(ipmiCmd[3]) + "] Expected Output")
                print "\nProcessed IPMI Output: [" + str(output) + "] != [" + str(ipmiCmd[3]) + "] Expected Output\n"
                return False

        # sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        # sph%<none>    %<2:3>     %<check~/tmp/output1.txt~NNP I-1000 Lower and Upper Thermal Thresholds : {2} {3}>
        elif 'check' in str(ipmiCmd[3]):
            logger.debug("Checking output in the file")
            params = ipmiCmd[3].split('~')
            logger.debug("Split successful")
            output = str(output).rstrip()
            output = str(output).rstrip('.')
            valCheck = str(params[2]).replace('{}', str(output))
            logger.debug("Looking for: ["+str(valCheck)+ "] in ["+str(params[1])+"]")

            retVal = search_str_in_file(server, valCheck, params[1])
            print "\nLooking for: [" + str(valCheck) + "] && [" +str(output)+ "] is the actual translated ipmi output\n"
            #print "Actual Translated Output: " +str(output)
            return retVal

        # sph%<ipmiCmd[1]>%<ipmiCmd[2]>%<ipmiCmd[3]>
        elif 'map' in str(ipmiCmd[3]).lower():
            logger.debug("Mapping with standard strings")
            output = cmdOutput[int(ipmiCmd[2])]
            #map(0)~(1)<path of file to verify>~(2)<output to be verified/config val to be retrieved>
            params = ipmiCmd[3].split('~')
            out= ipmiCmd[2]+output
            logger.debug("Reading value for : ["+str(out)+"] under [" + str(params[2]) +"] section")
            valCheck = sphConfig_SharedLib.get(params[2],out)
            logger.debug("Value fetched from sphconfig is: " +str(valCheck))

            retVal = search_str_in_file(server, valCheck, params[1])
            print "\nLooking for: [" + str(valCheck) + "] && [" + str(output) + "] is the actual translated ipmi output\n"
            # print "Actual Translated Output: " +str(output)
            return retVal


        # sph%ipmiCmd[1]%ipmiCmd[2]%ipmiCmd[3]
        else:
            logger.debug("Printing the output")
            print "Output: " +str(output)
            return True
    except Exception, e:
        logger.debug("IPMI Parsing Exception occurred: " +str(e))



def sut_info(shellcmd):
    global sut_IP,sut_uname,sut_pwd
    global sut_IP_list
    sut_IP = []
    sut_IP_list = []
    new_sut_IP_list = []
    
    sut_IP = ipConfig_SharedLib.get('IPMI', 'Default_SUT_IP').strip("\"")
    sut_uname = ipConfig_SharedLib.get('IPMI', 'IPMI_SUT_Username').strip("\"")
    sut_pwd = ipConfig_SharedLib.get('IPMI', 'IPMI_SUT_Password').strip("\"")

    filepath = config.get('AZUREPS', 'AzureWD')

    if "multiservermgr" in shellcmd.lower():
        if "-i " in shellcmd.lower():
            if "," not in shellcmd.lower().split("-i")[1].strip().split()[0]:
                sut_IP = shellcmd.lower().split("-i")[1].strip().split()[0]
            else:
                sut_IP_list = shellcmd.lower().split("-i")[1].strip().split()[0].split(",")

            if "all" in shellcmd.lower().split("-i")[1].strip().split()[0].lower():
                path = find("HostToBMC.txt", filepath)
                with open(path) as f:
                    HTB_contents = f.readlines()
                for line in HTB_contents:
                    new_sut_IP_list.append(line.split(",")[0])
                sut_IP_list = new_sut_IP_list
            
            elif "." not in shellcmd.lower().split("-i")[1].strip().split()[0]:
                path = find("HostToBMC.txt",filepath)
                with open(path) as f:
                    HTB_contents = f.readlines()
                if "," not in shellcmd.lower().split("-i")[1].strip().split()[0]:
                    sut_IP_list = []
                    sut_IP = shellcmd.lower().split("-i")[1].strip().split()[0]
                    for i in HTB_contents:
                        if sut_IP.lower() in i.lower():
                            sut_IP = i.split(",")[0]
                else:
                    for host_name in sut_IP_list:
                        for i in HTB_contents:
                            if host_name.lower() in i.lower():
                                new_sut_IP_list.append(i.split(",")[0])
                    sut_IP_list = new_sut_IP_list

            temp_sut_IP_list = []
            for item in sut_IP_list:
                if '.' in item.lower():
                    temp_sut_IP_list.append(item)
                else:
                    path = find("HostToBMC.txt",filepath)
                    with open(path) as f:
                        HTB_contents = f.readlines()
                    for line in HTB_contents:
                        if item.lower() in line.lower():
                            temp_sut_IP_list.append(line.split(",")[0])
            sut_IP_list = temp_sut_IP_list
                    
        if "-g " in shellcmd.lower():
            gp_name = shellcmd.split("-g")[1].strip().split()[0]
            sut_IP_list = []
            path = find("HostToBMC.txt",filepath)
            with open(path) as f:
                HTB_contents = f.readlines()
            if "ALL".lower() in gp_name.lower():
                for line in HTB_contents:
                    new_sut_IP_list.append(line.split(",")[0])
            else:
                for line in HTB_contents:
                    if gp_name.lower() in line.lower():
                        new_sut_IP_list.append(line.split(",")[0])
            sut_IP_list = new_sut_IP_list

        if "-u " in shellcmd.lower():
            sut_uname = shellcmd.split("-u")[1].strip().split()[0]
            
        if "-p " in shellcmd.lower():
            sut_pwd = shellcmd.split("-p")[1].strip().split()[0].strip(";")
 
    if "ism" in shellcmd.lower():
        sut_IP = shellcmd.split("-i")[1].strip().split()[0]
        if "-b " in shellcmd.lower() and "ignore" not in TC_Name:
            sut_uname = shellcmd.split("-b")[1].strip().split()[0].split("/")[0]
            sut_pwd = shellcmd.split("-b")[1].strip().split()[0].split("/")[1]

    if "sdptool " in shellcmd.lower() and "-h" not in shellcmd:
        sut_IP = shellcmd.split()[1]
        sut_uname = shellcmd.split()[2]
        sut_pwd = shellcmd.split()[3]

    logger.debug("IPMI SUT_IP_list:"+str(sut_IP_list))
    logger.debug("IPMI SUT_IP:"+sut_IP)
    logger.debug("IPMI SUT_Username:"+sut_uname)
    logger.debug("IPMI SUT_IP:"+sut_pwd)
    #print sut_IP,sut_IP_list,sut_uname,sut_pwd


def bmc_info(component):
    global sut_IP, sut_uname, sut_pwd
    retry = 0
    while retry < 5:
        try:
            ipmi_config = ConfigParser.ConfigParser()
            ipmi_cmds_path = os.path.abspath(
                os.path.join(os.path.dirname(__file__), os.pardir, 'Scripts', 'ipmi_cmds.ini'))
            ipmi_config.read(ipmi_cmds_path)
            sys_info = []

            if sut_IP == '' and "azureps" not in utility.lower():
                sut_IP = ipConfig_SharedLib.get(utility.upper(), 'EFI_IP')
                sut_uname = ipConfig_SharedLib.get(utility.upper(), 'usrName')
                sut_pwd = ipConfig_SharedLib.get(utility.upper(), 'usrPwd')

            if "fru" in component.lower() or "baseboard" in component.lower()or "backplane" in component.lower() or "power supply" in component.lower():
                component = 'fru'
                
            ipmi_cmd = (ipmi_config.get('IPMI_COMMANDS', component)) % (sut_IP, sut_uname, sut_pwd)

            # print "IPMI Command: ", ipmi_cmd
            logger.debug(ipmi_cmd)

            if "azureps" in utility.lower():
                SUT = {}
                SUT['ip'] = ipConfig_SharedLib.get('IPMI', 'IPMI_SUT_IP').strip("\"")
                SUT['usrName'] = ipConfig_SharedLib.get('IPMI', 'IPMI_SUT_Username').strip("\"")
                SUT['usrPwd'] = ipConfig_SharedLib.get('IPMI', 'IPMI_SUT_Password').strip("\"")

                server = connectToHost(SUT)
                message = executeCommand(server, ipmi_cmd)
                out_info = '\n'.join(message)
                server.close()
            else:
                logger.debug("Trigger IPMI command from within this system")
                p = subprocess.Popen(ipmi_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                out_info, error = p.communicate()
                logger.debug(" IPMI Output: " + out_info)
                logger.debug(" IPMI Error if any: " + error)

            out_info_list = out_info.strip().split()
            # print out_info_list

            '''BIOS Version'''
            if "bios" in component.lower():
                component_name = "BIOS Version"
                # print "BIOS Version ........ : %s"%(("".join(out_info_list[1:]).decode("hex")))
                bios_version = "".join(out_info_list[1:22]).decode("hex")
                # bmc_info.append(("".join(out_info_list[1:]).decode("hex")))
                logger.debug("BIOS Version ........ : " + str(bios_version))
                return bios_version

            '''SDR Version'''
            if "sdr" in component.lower():
                component_name = "SDR Version"
                # print "SDR Version ......... :",".".join(out_info.strip().split()[1:])
                sdr_version = ".".join(out_info.strip().split()[1:])
                # bmc_info.append(".".join(out_info.strip().split()[1:]))
                logger.debug("SDR Version ........ : " + str(sdr_version))
                return sdr_version

            '''ME Version'''
            if "me" in component.lower():
                component_name = "ME Version"
                build = out_info_list[12] + out_info_list[13]
                build = build[:-1]
                # print "ME Version .......... : %s%s.0%s.0%s.%s"%(int(out_info_list[2][:-1])&7,out_info_list[2][-1],out_info_list[3][:-1],out_info_list[3][-1],build)
                me_version = ("%s%s.0%s.0%s.%s") % (
                int(out_info_list[2][:-1]) & 7, out_info_list[2][-1], out_info_list[3][:-1], out_info_list[3][-1],
                build)
                # bmc_info.append(me_version)
                logger.debug("ME Version ........ : " + str(me_version))
                return me_version

            '''BMC Version and Build ID'''
            if "bmc" in component.lower() and "backup" not in component.lower():
                component_name = "BMC Version and Build ID"
                logger.debug("Firing BMC IPMI command")
                buildID = "%s%s%s%s" % (out_info_list[-1], out_info_list[-2], out_info_list[-3], out_info_list[-4])
                #fwver = "%s.%s.%s" % (str(int(out_info_list[2])), str(int(out_info_list[3])), buildID)
                fwver = "%s.%s" % (str(int(out_info_list[2])), str(int(out_info_list[3])))
                # print "BMC Version ......... : %s"%(fwver)
                # bmc_info.append(fwver)
                # print "BMC Build ID ........ : %s"%(buildID)
                # bmc_info.append(buildID)
                if "bmc version" in component.lower():
                    logger.debug("BMC Version ........ : " + str(fwver))
                    return fwver
                elif "buildid" in component.lower():
                    logger.debug("BMC Build ID ........ : " + str(buildID))
                    return buildID

            '''Backup BMC Version'''
            if "backup bmc" in component.lower():
                component_name = "Backup BMC Version"
                bfwver = "%s.%s" % (str(int(out_info_list[32])), str(int(out_info_list[33])))
                bBuildID = "%s%s%s%s" % (out_info_list[37], out_info_list[36], out_info_list[35], out_info_list[34])
                # print "Backup BMC Version .. : %s.%s"%(bfwver,bBuildID)
                backup_bmc_ver = "%s.%s" % (bfwver, bBuildID)
                # bmc_info.append(backup_bmc_ver)
                if "bmc version" in component.lower():
                    logger.debug("Backup BMC Version ........ : " + str(bfwver))
                    return bfwver
                elif "buildid" in component.lower():
                    logger.debug("Backup BMC Build ID ........ : " + str(bBuildID))
                    return bBuildID

            '''RMM Key'''
            if "rmm key" in component.lower():
                component_name = "RMM Key"
                rmmflag = True
                if "unable to send raw command" in str(out_info).lower():
                    component = 'rmm key 2'
                    ipmi_cmd = (ipmi_config.get('IPMI_COMMANDS', component)) % (sut_IP, sut_uname, sut_pwd)
                    server = connectToHost(SUT)
                    message = executeCommand(server, ipmi_cmd)
                    out_info = '\n'.join(message)
                    server.close()
                    out_info_list = out_info.strip().split()
                if len(out_info_list) < 2:
                    if out_info_list[0] == "00":
                        rmmflag = False
                elif len(out_info_list) > 1:
                    if out_info_list[1] == "00":
                        rmmflag = False
                else:
                    rmmflag = True

                if not rmmflag:
                    logger.debug("RMM Key ........ : Not Installed\RMM4 Lite Absent")
                    return ["Not Installed", "RMM4 Lite Absent", "RMM Absent"]
                else:
                    logger.debug("RMM Key ........ : Installed\RMM4 Lite Present")
                    return ["Installed", "RMM4 Lite Present", "RMM Present"]

            '''LED Status'''
            if "led status" in component.lower():
                component_name = "LED Status"
                led_status = int(out_info_list[2]) / 10
                if led_status == 4:
                    logger.debug("LED Status ........ : OFF")
                    return "Off"
                else:
                    logger.debug("LED Status ........ : ON")
                    return "On"

            '''Power Status'''
            if "power status" in component.lower():
                component_name = "Power Status"
                if "chassis power is on" in out_info.lower():
                    logger.debug("Power Status ........ : ON")
                    return "On"
                else:
                    logger.debug("Power Status ........ : OFF")
                    return "Off"
                
            '''FRU\Baseboard\Backplane\Power supply'''
            if "fru" in component.lower() or "baseboard" in component.lower()or "backplane" in component.lower() or "power supply" in component.lower():
                component_name, fru_output = fru_edit(component,str(out_info))
                #logger.debug(str(component_name) + ": " + str(fru_output))
                return fru_output

            else:
                logger.debug(component + " ........ : " + str(out_info))
                return out_info


        except Exception, e:
            retry += 1
            logger.debug("Unable to communicate with BMC IP to verify " + component_name)
            logger.debug("Exception: " + str(e))
            if retry < 4:
                logger.debug("Retry # " +str(retry+1) +" in progress...")
            else:
                logger.debug("Retry exhausted")

            print "\n\033[91mUnable to communicate with BMC IP using IPMI.\033[00m\n"
            logger.debug("Unable to communicate with BMC IP.")
            return "Unable to communicate with BMC IP."

def fru_edit(component,ipmi_out):
    fru_list,baseboard_list,backplane_list,powersupply_list = [],[],[],[]
    fruflag, backplaneflag, pwrflag = False, False, False
    ipmi_out_list = ipmi_out.split('\n')
    for line in ipmi_out_list:
        if line.lower() == '' or ".." in  line.lower():
            continue
        if "builtin fru device" in  line.lower():
            bbflag = True
            continue
        if "pwr supply 1" in  line.lower() or "pwr supply 2" in  line.lower():
            pwrflag = True
            continue
        if "hs backplane" in  line.lower():
            backplaneflag = True
            continue

        fru_list.append(line.split(": ")[1])
        if bbflag and not backplaneflag and not pwrflag:
            baseboard_list.append(line.split(": ")[1])
        if pwrflag and not backplaneflag:
            powersupply_list.append(line.split(": ")[1])
        if backplaneflag :
            backplane_list.append(line.split(": ")[1])

    if "fru" in component.lower():
        logger.debug("FRU List: " + str(fru_list))
        return "FRU",fru_list
    elif "baseboard" in component.lower():
        logger.debug("Baseboard List: " + str(baseboard_list))
        return "Baseboard",baseboard_list
    elif "power supply" in component.lower():
        logger.debug("Power Supply List: " + str(powersupply_list))
        return "Power Supply",powersupply_list
    elif "backplane" in component.lower():
        logger.debug("Backplane List: " + str(backplane_list))
        return "Backplane",backplane_list
    
def sys_info_bmc():
    sys_info = []
    global utility
    if "sdp" in utility.lower():
        sys_info_components = ["bios","sdr","me","bmc version","bmc buildid","backup bmc version","rmm key"]
    if "imsm" or "azure" in utility.lower():
        sys_info_components = ["bios","sdr","me","bmc version","rmm key"]

    for item in sys_info_components:
       sys_info.append(bmc_info(item))
    # print sys_info
    return sys_info


def ism_version():
    ver_info = []
    ver_info.append(config.get('IMSM_Version', 'IMSM_Version'))
    ver_info.append(config.get('IMSM_Version', 'Build Version'))
    ver_info.append(config.get('IMSM_Version', 'Utilities Version'))

    return ver_info
# ---------------------------------------------------------END of Section-----------------------------------------------


# --------------------------------------------------------SYSINFO Section-----------------------------------------------
def custom_deploy_efi(utility, shellpath, executable, shellcmd, shell_expected_out, test_name):

        if utility == 'FWPIAUPD' or utility == 'IFLASH32' or utility == 'FRUSDR' or utility == 'SELVIEWER':
            logger.debug('Creating Deploy.nsh file in: ' + shellpath)
            if ',' in shellcmd:
                shellcmd = shellcmd.split(',')
                create_file_text(shellpath + '//', 'deploy.nsh', executable, 'w')
                for cmds in shellcmd:
                    create_file_text(shellpath + '//', 'deploy.nsh', cmds + '\n', 'a')
                # shellcmd=" ;".join(shellcmd)
            else:
                create_file_text(shellpath + '//', 'deploy.nsh', executable, 'w')
                create_file_text(shellpath + '//', 'deploy.nsh', shellcmd, 'a')

        else:
            logger.debug('Creating Deploy.nsh file in: ' + shellpath)
            logger.debug('Command being written is: ' + executable)
            create_file_text(shellpath + '//', 'deploy.nsh', executable, 'w')

            logger.debug('Appending Deploy.nsh file to: ' + shellpath)
            logger.debug('Command being added is: ' + shellcmd)
            create_file_text(shellpath + '//', 'deploy.nsh', shellcmd, 'a')

        if utility.lower() == "syscfg" and "get_ini" in test_name.lower():
            file_name = shellcmd.split()[2]
            if os.path.isfile(shellpath + '/' + file_name):
                os.remove(shellpath + '/' + file_name)
                logger.debug("Previous run's " + file_name + " file deleted")
            create_file_text(shellpath + '//', 'deploy.nsh', '\ncp ' + file_name + ' deploy_details.log', 'a')
            
        if utility.lower() == "sysinfo" and "inst_generate_log" in test_name.lower():
            create_file_text(shellpath + '//', 'deploy.nsh', '\necho "******* Reading PCILog *******" >> \deploy_details.log', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\ntype LogFiles\PCI_log.txt >> \deploy_details.log', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\ntype LogFiles\PCI_log.txt', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\necho "******* Completed PCILog *******" >> \deploy_details.log', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\necho "******* Reading SYSInfoLog *******" >> \deploy_details.log', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\ntype LogFiles\sysinfo_log.txt >> \deploy_details.log', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\ntype LogFiles\sysinfo_log.txt', 'a')
            create_file_text(shellpath + '//', 'deploy.nsh', '\necho "******* Completed SYSInfoLog *******" >> \deploy_details.log', 'a')

        output, error = efi_execute(utility, shellpath)

        #if utility.lower() == "syscfg" and "restore_compare" in test_name.lower():
            #logger.debug("Copying syscfg log files to /temp location")
            #syscfg_restore_settings(shellpath)

        if utility.lower() == "sysinfo" and "Inst_Generate_Log" in test_name:
            logger.debug("Copying sysinfo and pci log files to /temp location")
            sysinfo_details_logs()

        return output, error


#functon to create deploy.nsh for efi group execution
#function based on deploy.nsh creation in custom_deploy_efi()
def create_deploy(shellpath, efi_deploy_list):
    for i in range(len(efi_deploy_list)):
        test_name = efi_deploy_list[i][0]
        shellcmd = efi_deploy_list[i][1]
        if i == 0:
            logger.debug('Creating Deploy.nsh file in: ' + shellpath)
            logger.debug('Test Case being added is: ' + test_name)
            create_file_text(shellpath + '//', 'deploy.nsh', 'echo ' + '[' + test_name + ']', 'w')
            logger.debug('Command being added is: ' + shellcmd)
            if ',' in shellcmd:
                shellcmd = shellcmd.split(',')
                for cmds in shellcmd:
                    create_file_text(shellpath + '//', 'deploy.nsh', '\n' + cmds , 'a')
            else:
                create_file_text(shellpath + '//', 'deploy.nsh', '\n' + shellcmd, 'a')
        else:
            logger.debug('Command being added is: ' + shellcmd)
            logger.debug('Test Case being added is: ' + test_name)
            create_file_text(shellpath + '//', 'deploy.nsh', '\necho ' + '[' + test_name + ']', 'a')
            logger.debug('Command being added is: ' + shellcmd)
            if ',' in shellcmd:
                shellcmd = shellcmd.split(',')
                for cmds in shellcmd:
                    create_file_text(shellpath + '//', 'deploy.nsh', '\n' + cmds , 'a')
            else:
                create_file_text(shellpath + '//', 'deploy.nsh', '\n' + shellcmd, 'a')
        create_file_text(shellpath + '//', 'deploy.nsh', '\necho " "', 'a')

#below functon taken from custom_deploy_efi() and can be reused later
def efi_execute(utility, shellpath):
    try:
        efi_bmc_ip = ipConfig_SharedLib.get(utility, 'EFI_IP')
        efi_bmc_user = ipConfig_SharedLib.get(utility, 'efiUsrName')
        efi_bmc_password = ipConfig_SharedLib.get(utility, 'efiUsrPwd')
        logger.debug('EFI BMC IP: ' + efi_bmc_ip)

        deploymentCmd = 'SDPTool ' + efi_bmc_ip + ' ' + efi_bmc_user + ' ' + efi_bmc_password + ' custom_deploy ' + shellpath
        logger.debug('Custom Deploy Command: ' + deploymentCmd)

        logIP = efi_bmc_ip.replace('.', '_')
        ipFolder = "/usr/local/log/SDPTool/Logfiles/" + logIP
        logger.debug("Checking existence of folder : " + str(ipFolder))

        if os.path.exists(ipFolder):
            logger.debug("Folder exists, deleting it now")
            shutil.rmtree(ipFolder)
        else:
            logger.debug("Folder is Not Present, nothing to delete")

        if os.path.exists("/temp/temp.txt"):
            logger.debug("Deleting temp.txt")
            os.remove("/temp/temp.txt")
        else:
            logger.debug("Temp.txt file does not exist")

        logger.debug('Triggered Execution in EFI Environment')
        time.sleep(10)
        p = subprocess.Popen(deploymentCmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             shell=True)
        p.stdin.write(b'y\n')

        output, error = p.communicate()
        logger.debug("Done with Execution")
        logger.debug('Raw Output: ' + output)
        logger.debug('Error Output: ' + error)

        time.sleep(30)
        logger.debug("Gathering Info from Custom Deploy Output file")
        logIP = "/usr/local/log/SDPTool/Logfiles/" + logIP + "/custom_deploy_output.txt"
        logger.debug('LogFileLocation: ' + logIP)

        retry = 0
        while retry < 10:
            logger.debug("Attempt #: " + str(retry))
            if os.path.exists(logIP):
                logger.debug("LogFile is available in location: " + logIP)
                break
            else:
                time.sleep(30)
                logger.debug("Waiting for 30 secs and retrying")
            retry = retry + 1

        output = readfile(logIP)
        logger.debug('file contents: ' + str(output))

        return output, error

    except Exception, e:
        logger.debug('Exception error: ' + str(e))
        logger.exception("Not able to execute the command in EFI Environment")
        return '', 'Wrong Output'


# Splits one common output file from efi execution, into seperate files based on test case names
def efi_file_split():
    logger.debug("Splitting and Generating EFI result files")
    inpPath = "/temp/temp_output.txt"
    destPath = "/temp/"
    counter = 0
    # logger.debug("Readfile: " + str(file_path))
    # fd = open(file_path, "r")
    with open(inpPath, "r") as f:
        for line in f:
            # line = line.replace('\xef\xbb\xbf', "")
            logger.debug("Line before replacing special character: " + str(line))
            line = line.replace('\xe0', "")
            line = line.replace('\xff\xfe', "")
            line = line.replace('\n', "")
            # print("Line read is: ", str(line))
            logger.debug("Line processed: " + str(line))
            # if line.startswith('[') and line.find('_start'):
            # if line.startswith('[') and '_start' in str(line):

            if line.startswith('[TC'):
                # print("Line read again is: ", str(line))
                counter = counter + 1
                logger.debug("[TC found, creating new file")
                # fName = destPath + str(line)+".txt"
                fName = destPath + str(counter) + ".txt"
                # print("File Name is:", str(fName))
                logger.debug("Created new file: " + str(fName))
                newFile = open(fName, 'w+')

            newFileWrite = open(fName, 'a+')
            newFileWrite.write(line)
            newFileWrite.write("\n")


def efi_output_verify(output, error, efi_deploy_list):
    logger.debug("Validating output from EFI result files")
    path = '/temp/'
    count = 0
    destination = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'TestResults', "EFIGroupTests"))
    for i in range(len(efi_deploy_list)):
        count = count + 1
        test_name = efi_deploy_list[i][0]
        print("Test Name: ", test_name)
        logger.debug("Test Name: " + str(test_name))
        print("Cmd: ", str(efi_deploy_list[i][1]))
        shell_expected_out = efi_deploy_list[i][2]
        # print("Shell Expected Out: ", shell_expected_out)
        logger.debug("Expected Output: " + str(shell_expected_out))
        # src_path = find(test_name, path)
        # print("SourcePath: ", src_path)
        src_path = path + str(count) + ".txt"
        # print("Hard Coded Source Path: ", src_path)
        logger.debug("File Path: " + src_path)
        shutil.copyfile(src_path, "/temp/temp.txt")
        contents_log = readfile("/temp/temp.txt")
        # print("File Contents: ", str(contents_log))
        logger.debug("File Contents: " + str(contents_log))
        # result, message = edit_shell_response(output, error, shell_expected_out, 0)
        result, message = edit_shell_response(contents_log, error, shell_expected_out, 0)
        print("Test Result: ", str(result))
        logger.debug("TestResult: " + str(result))
        print("\n")
        if "step" not in test_name.lower():
            write_txt(destination, test_name, result, message)


def setUtilityName(file_name):
    global utility
    utility = file_name
    logger.debug("Utility Name is " + utility)
    return utility

'''
def os_check():
    global linux_os
    global win_os
    global efi_level_os
    linux_os = config.get('TC_EXECUTION', 'LINUX')
    win_os = config.get('TC_EXECUTION', 'WINDOWS')
    efi_level_os = config.get('TC_EXECUTION', 'EFI_IP')
    logger.debug("Linux OS : " + linux_os)
    logger.debug("Windows OS : " + win_os)
    logger.debug("Efi Level OS : " + efi_level_os)
    return linux_os, win_os, efi_level_os
'''


def getOS():
    return os_info

def getTestCaseName(test_name):
    global TC_Name
    TC_Name = test_name
    return TC_Name

def efi_stream_editor(shellpath, shellcmd):
    temp_path= "/temp"

    if os.path.isdir(temp_path) == False:
        logger.debug("Temp folder doesn't not exists, creating now")
        os.makedirs(temp_path)
    else:
        logger.debug("Temp folder already exists")

    utility = "SYSCFG"
    log_ip = ipConfig_SharedLib.get(utility, 'EFI_IP').replace('.','_')
    #print log_ip
    syscfg_details_path = "/usr/local/log/SDPTool/Logfiles/" + log_ip + "/custom_deploy_details.txt"
    logger.debug("syscfg_path : " + syscfg_details_path)
    if os.path.isfile(syscfg_details_path):
        command = shellcmd.rsplit(' ', 1)
        sed_command = command[0] + ' ' + syscfg_details_path
        #subprocess.call(["sed", "-i", 's/Quiet Boot=Enabled /Quiet Boot=Disabled/g', syscfg_details_path])
        subprocess.call([sed_command], shell=True)
        logger.debug("Running the command " + sed_command + " in Host")
        contents = readfile(syscfg_details_path)
        create_file_text(shellpath + '/', command[1], contents, 'a')
        logger.debug(command[1] + " created in " + shellpath)

def sysinfo_details_logs():
    temp_path= "/temp"

    if os.path.isdir(temp_path) == False:
        logger.debug("Temp folder doesn't not exists, creating now")
        os.makedirs(temp_path)
    else:
        logger.debug("Temp folder already exists")

    utility = "SYSINFO"
    log_ip = ipConfig_SharedLib.get(utility, 'EFI_IP').replace('.', '_')
    # print log_ip
    sysinfo_details_path = "/usr/local/log/SDPTool/Logfiles/" + log_ip + "/custom_deploy_details.txt"
    sysinfo_details_output_path = "/usr/local/log/SDPTool/Logfiles/" + log_ip + "/custom_deploy_output.txt"

    if os.path.isfile(sysinfo_details_path):
        logger.debug("Deploy Details file created successfully")
        contents = readfile(sysinfo_details_path)
        outText = contents.split('\n')
    else:
        logger.debug("Deploy Details file is not present")
        contents = readfile(sysinfo_details_output_path)
        outText = contents.split('\n')
        # print outText

    start_pcilog,end_pcilog,start_sysinfolog,end_sysinfolog= 0,0,0,0

    for i in range(len(outText)):
        if "Reading PCILog" in  outText[i]:
            logger.debug("Identified PCI Starting Region: Line = " + str(i) + str(outText[i]))
            start_pcilog=i
        elif "Completed PCILog" in  outText[i]:
            logger.debug("Identified PCI End Region: Line = " + str(i) + str(outText[i]))
            end_pcilog=i
        elif "Reading SYSInfoLog" in  outText[i]:
            logger.debug("Identified SysInfo Starting Region: Line = " + str(i) + str(outText[i]))
            start_sysinfolog=i
        elif "Completed SYSInfoLog" in  outText[i]:
            logger.debug("Identified SysInfo End Region: Line = " + str(i) + str(outText[i]))
            end_sysinfolog=i

    # print  start_pcilog,end_pcilog,start_sysinfolog,end_sysinfolog
    create_file_text(temp_path + '/', 'PCILog.txt', "", 'w')
    for i in range(start_pcilog+1,end_pcilog-1):
        create_file_text(temp_path + '/', 'PCILog.txt', outText[i], 'a')

    logger.debug("Completed writing PCI content into PCILog.txt")

    create_file_text(temp_path + '/', 'SYSInfoLog.txt', "", 'w')
    for i in range(start_sysinfolog+1,end_sysinfolog-1):
        create_file_text(temp_path + '/', 'SYSInfoLog.txt', outText[i], 'a')

    logger.debug("Completed writing SYSInfo content into SYSInfoLog.txt")

def sysinfo_search(output, category):

    retVal = False
    failCatch = False
    temp_contents = []
    new_list = []
    remote_path = '/root/'
    ssh = config.get("TC_EXECUTION","SSH")

    SUT = {}
    SUT['ip'] = ipConfig_SharedLib.get(utility, 'SUT')
    SUT['usrName'] = ipConfig_SharedLib.get(utility, 'usrName')
    SUT['usrPwd'] = ipConfig_SharedLib.get(utility, 'usrPwd')

    if "windows" in category.lower():
        temp_dir = 'C:\\temp\\'
    else :
        #*temp_dir = '/temp/'
        temp_dir = '/tmp/'
    logger.debug("Directory path of temp folder:" + temp_dir)
    
    logger.debug("Writing Output details into Temp.txt")
    create_file_text(temp_dir, 'temp.txt', output, 'w+')

    #Moving LogFiles created under /Scripts to /temp/
    if "linux" in category.lower():
        if os.path.isfile(temp_dir + "SYSInfoLog.txt") == False or os.path.isfile(temp_dir + "PCILog.txt") == False:
            create_file_text(temp_dir, 'SYSInfoLog.txt',"", 'w')
            create_file_text(temp_dir, 'PCILog.txt',"", 'w')
        #Below line is the PCI_Log file that would be located in the local system
        pci_src=os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Scripts','LogFiles','PCI_log.txt'))
        shutil.copyfile(pci_src, temp_dir + "PCILog.txt")
        sys_src=os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Scripts','LogFiles','sysinfo_log.txt'))
        shutil.copyfile(sys_src, os.path.join(temp_dir , 'SYSInfoLog.txt'))

    #Moving LogFiles created under /binaries into C:\temp
    if "windows" in category.lower():
        if os.path.isfile(os.path.join(temp_dir , 'SYSInfoLog.txt')) == False:
            create_file_text(temp_dir, 'SYSInfoLog.txt',"", 'w')
        sys_src=os.path.abspath(os.path.join(config.get('SYSINFO', 'sysinfo_WD'),'LogFiles','sysinfo_log.txt'))
        shutil.copyfile(sys_src, os.path.join(temp_dir , 'SYSInfoLog.txt'))

    #Reads contents from Sysinfo log maintained at C:\temp or \temp depending on OS
    #and stores in contents_log
    contents_log = readfile(os.path.abspath(temp_dir + "SYSInfoLog.txt"))

    #Reads PCI Log maintained at C:\temp or \temp depending on OS
    #and overwrites into contents_log
    if "linux" in category.lower() and "lspci" in category.lower():
        contents_log = readfile(temp_dir + "PCILog.txt")

    #Reading the Command output from temp.txt file
    f = open(os.path.abspath(temp_dir + 'temp.txt'), "r")
    temp_contents = f.readlines()

    if "efi config" in category.lower() or "linux config" in category.lower() or "windows power" in category.lower():
        logger.debug("Leaving test as is in temp.txt")
        del temp_contents[:2]
   
    elif "efi system" in category.lower() or "linux system" in category.lower() or "windows system" in category.lower() :
        logger.debug("Removing 1st few lines")
        if "windows system" in category.lower() :
            del temp_contents[:5]
        else:
            del temp_contents[:4]

    elif "linuxos" in category.lower() or "kernel" in category.lower():
        logger.debug("Linux OS verification, deleting No lines")

    else:
        del temp_contents[:1]
        logger.debug("general case, deleting only 1st line")

    f.close()

    #print "Temp_contents: \n",temp_contents
    for i in temp_contents:
        contentSearched = i.strip('\r').strip('\n')
        if "windows" in category.lower():
            contentSearched = i.strip()

        logger.debug("SEARCHING : [["+ str(contentSearched) +"]]")

        if "lan info" in category.lower():
            if "LAN Failover Mode".lower() in contentSearched.lower():
                logger.debug("searching for LAN Failover Mode")
                contentSearched = contentSearched.split(":")[0]
                logger.debug("Trimmed LAN Failover Mode" + str(contentSearched))

        if "efi config" in category.lower():
            contentSearched = contentSearched.replace('\r', '')
            contentSearched = contentSearched.replace(' v', '')
            logger.debug("EDK String being processed is: " + str(contentSearched))
            edkDetails = contentSearched.split("(")
            logger.debug("split ( ->EDKDetails: " + str(edkDetails))
            tempEdkVersion = edkDetails[0].split(" ")
            edkVersion = tempEdkVersion[1]
            logger.debug("EDK Version: " + str(edkVersion))
            #Temporary fix, need to change the logic below
            #tempEdkString = edkDetails[1].split(",")
            #edkString = tempEdkString[0]
            #logger.debug("EDK String: " + str(edkString))

            #contentSearched = edkVersion + edkString
            #contentSearched = edkString
            contentSearched = edkVersion
            logger.debug("Concatenated EDK Details: " + str(contentSearched))

        if "fwpiaupd info" in category.lower():
            logger.debug("filtering for Op Code existence")
            if "op code" in contentSearched.lower():
                logger.debug("Op Code searching")
                contentSearched = contentSearched.split(":")[1]
                contentSearched = contentSearched.strip()
                logger.debug("Op Code version Retrieved is: " + str(contentSearched))
            else:
                logger.debug("fwpiaupd search set to null as opcode was not found")
                contentSearched = ""

        if "iflash config" in category.lower():
            keySearched = contentSearched.split(" ")
            contentSearched = keySearched[-1]
            logger.debug("First Element in list is: " + str(keySearched[0]))
            logger.debug("Split String is: " +str(contentSearched))
            if "primary" in keySearched[0].lower() or "secondary" in keySearched[0].lower():
                logger.debug("Forming BIOS string to compare")
                verSearched = contentSearched.split(".")
                contentSearched = verSearched[0]+"."+verSearched[1]+"."+verSearched[2]+"."+verSearched[3]+"."+verSearched[4]
                logger.debug("Concatenated BIOS String is: " + str(contentSearched))

        if "User Status:" in contentSearched or "Successfully Completed" in contentSearched or "Chassis Information" in contentSearched \
                or "Displaying SDR Area" in contentSearched or "Displaying SMBios Area" in contentSearched or "BoardInformation  (Type 2)" in contentSearched\
                or "ChassisInformation (Type 3)" in contentSearched or "SystemInformation  (Type 1)" in contentSearched or "Secondary BIOS Version" in contentSearched \
                or "BIOS Boot Region" in contentSearched:
            logger.debug("Ignoring Title/Status/Unnecessary Version strings")

        #Checking the processed search string with either Sysinfolog or pci log in contents_log
        elif contentSearched in contents_log:
            retVal = True
            #logger.debug("FOUND : [["+ str(contentSearched) +"]]")

        else:
            logger.debug("Missing: " + str(contentSearched) + ": attempting split and search")

            if "kernel" in category.lower():
                logger.debug("Ignoring the Size and Used by columns")
                contentSearched = contentSearched.split(" ")
                contentSearched = contentSearched[0]
                if contentSearched in contents_log:
                    retVal = True

            else:

                if ":" in str(contentSearched):
                    logger.debug(": exists in the string")
                    contentSearched = contentSearched.split(":")
                    contentSearched = contentSearched[1]
                    logger.debug("SPLIT & SEARCHING FOR :" + str(contentSearched))
                    tempcontentSearched = contentSearched.lower()
                    tempcontentSearched = tempcontentSearched.replace(" ", "")
                    tempcontents_log = contents_log.lower()
                    tempcontents_log = tempcontents_log.replace(" ", "")
                    if "<outofspec>" in tempcontentSearched or "notspecified" in tempcontentSearched or "notprovided" in tempcontentSearched or "nomoduleinstalled" in tempcontentSearched or "nodimm" in tempcontentSearched or "node1" in tempcontentSearched or "node2" in tempcontentSearched or "node3" in tempcontentSearched or  "node4" in tempcontentSearched:
                        logger.debug("Ignoring Searching of : " + tempcontentSearched)
                    else:
                        if contentSearched in contents_log or tempcontentSearched in tempcontents_log:
                            retVal = True
                            #logger.debug("SPLIT FOUND : [[" + str(contentSearched) + "]]")
                            #logger.debug("SPLIT FOUND : [[" + str(tempcontentSearched) + "]]")
                        else:
                            logger.debug(": does not exist in the search string")
                            logger.debug("SPLIT MISSING : [[" + str(contentSearched) + "]]")
                            logger.debug("SPLIT MISSING : [[" + str(tempcontentSearched) + "]]")
                            # print "MISSING SysInfoSearch : ", retVal
                            failCatch = True
                            if "no " not in contentSearched.lower() and "bank" not in contentSearched.lower() and "not" not in contentSearched.lower() and "none" not in contentSearched.lower() and "unknown" not in contentSearched.lower() and "<OUT OF SPEC>".lower() not in contentSearched.lower():
                                new_list.append(contentSearched)
                else:
                    logger.debug("Colon does not exist in the search string, nothing to split")
                    logger.debug("MISSING : [[" + str(contentSearched) + "]]")
                    # print "MISSING SysInfoSearch : ", retVal
                    failCatch = True
                    if "no " not in contentSearched.lower() and "bank" not in contentSearched.lower() and "not" not in contentSearched.lower() and "none" not in contentSearched.lower() and "unknown" not in contentSearched.lower() and "<OUT OF SPEC>".lower() not in contentSearched.lower():
                        new_list.append(contentSearched)

    #print "New list:\n",new_list

    if failCatch == True:
        if new_list is not []:
            for i in new_list:
                if "socket" in i.lower():
                    item = ":" + i.strip("\t").split(": ")[1]
                elif ": " in i:
                    item = i.strip("\t").split(": ")[1]
                else:
                    item = i
                #print item
                logger.debug("Fail Catch: " +str(item))
                if item.lower() in contents_log.lower():
                    retVal = True
                    # print "True"
                else:
                    # print "False"
                    return False

    return retVal


def teardown():
    logPath = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'TestResults'))
    if platform.system() == "Linux":
        tempPath = '/temp/'
    elif  platform.system() == "Windows":
        tempPath = 'C:\\temp\\'
    if  os.path.exists(logPath) or os.path.exists(tempPath):
        if  os.path.exists(logPath):
            shutil.rmtree(logPath)
        else:
            logger.debug("'TestResults' folder doesn't exist.")
        if  os.path.exists(tempPath):
            shutil.rmtree(tempPath)
        else:
            logger.debug("'temp' folder doesn't exist.")
    else:
        logger.debug("Teardown not needed.")



#------------------------------------------------------------END of Section--------------------------------------------------

#===================================================== INSTALLATION / UNINSTALLATION ========================================

def installPreReq(utility):
    logger.debug("Deleting all existing files")
    shutil.rmtree('../Utilities_Packages/Utilities/'+utility)

def linuxOSDetails(output, utility):
    try:
        if "Red Hat Enterprise Linux" in output and "8.0" in output:
            logger.debug("RHEL 8 OS")
            return config.get(utility.upper(),'rhel8_rpm_Path')
        elif "Red Hat Enterprise Linux Server" in output:
            logger.debug("Non RHEL 8 OS")
            return config.get(utility.upper(),'rhel_rpm_Path')
        elif "SLES" in output:
            logger.debug("SLES OS")
            return config.get(utility.upper(),'sles_rpm_Path')
    except Exception, e:
        logger.debug("Exception Occurred Retrieving RPM Path : " +str(e))


#---------------------------------------------------- END OF SECTION --------------------------------------------------------
