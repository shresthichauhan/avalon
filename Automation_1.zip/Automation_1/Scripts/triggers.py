import ConfigParser, subprocess, os, time
from sharedLib import *
from logger import *
from inband import *
import re
from BIOS_Option_Command import *

config = ConfigParser.ConfigParser()
config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir,'Datafeed','config.ini'))
config.read(config_path)
#dir_path = config.get('FWUPDPID','FWUPDPID_WD')

ipConfig = ConfigParser.ConfigParser()
ipConfig_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'ipConfig.ini'))
ipConfig.read(ipConfig_path)

os_info = ''

# trigger commands
def trigger_shell(shellpath, test_name, shellcmd, shell_expected_out, cwd_name, option):
    executionFlag = False
    ssh = config.get('TC_EXECUTION', 'ssh')
    SUT = {}
    p=''
    dir_path = os.getcwd()
    dir_path = os.path.join(dir_path.split("\\")[0],"\\",cwd_name)
    print "\nCmd: ", shellcmd
    logger.debug("\nCmd: " + shellcmd)
    #print(dir_path)
    if option == 1:
        from inputKeys import provisionUsr, provisionPwd, pressYes, pressNo, enterKey, provisionKeys
        #from inputKeys import *
        #powershellCmd = "/k " + shellCmd + "\n"
        # conversionFlag = True
        word = ''
        # while(conversionFlag):
        aps_msmIP = ipConfig.get("AZUREPS","MSM_IP")
        apsSIP = ipConfig.get("AZUREPS","singleIP")
        apsMIP = ipConfig.get("AZUREPS","multipleIP")
        apsSH = ipConfig.get("AZUREPS","singleHost")
        apsMH = ipConfig.get("AZUREPS","multipleHost")
        apsusr = ipConfig.get("AZUREPS","Username")
        apspwd = ipConfig.get("AZUREPS","Password")
        apsGp = ipConfig.get("AZUREPS","Gp")
        apsDBpwd = ipConfig.get("AZUREPS","dbPWD")
        AzureWD = config.get("AZUREPS", "AzureWD")
        vmPwd = ipConfig.get("AZUREPS", "VMPassword")

        if "{msm_ip}" in shellcmd or "{singleIP}" in shellcmd or "{multipleIP}" in shellcmd or "{singleHost}" in shellcmd or "{multipleHost}" in shellcmd or "{U}" in shellcmd or "{P}" in shellcmd or "{Gp}" in shellcmd or "{dbPWD}" in shellcmd:
            word = shellcmd.split('{')[1].split('}')[0]
            shellcmd = shellcmd.replace('{msm_ip}', aps_msmIP).replace('{singleIP}', apsSIP).replace('{multipleIP}', apsMIP).replace('{singleHost}', apsSH).replace('{multipleHost}', apsMH).replace('{U}', apsusr).replace('{P}', apspwd).replace("{Gp}", apsGp).replace("{dbPWD}", apsDBpwd)
            #logger.debug('Shell Cmd: ' + shellcmd)
            #print "\nResolved Cmd: ", shellcmd
            #logger.debug("Resolved Cmd: " + shellcmd)
        if "{singleIP}" in shell_expected_out or "{Gp}" in shell_expected_out or "{singleHost}" in shell_expected_out or "{path}" in shell_expected_out:
            word = shell_expected_out.split('{')[1].split('}')[0]
            apsSIP = apsSIP.replace(".","_")
            shell_expected_out = shell_expected_out.replace("{singleIP}", apsSIP).replace('{Gp}', apsGp).replace('{singleHost}', apsSH).replace('{path}', AzureWD)
            logger.debug("Resolved Expected Output: " + str(shell_expected_out))
        '''
            if "{" in shellcmd :
                word = shellcmd.split('{')[1].split('}')[0]
                if ("{"+word+"}") in shellcmd and word != "":
                    shellcmd = shellcmd.replace(("{"+word+"}"), ipConfig.get("AZUREPS",word))
            if "{" in shell_expected_out:
                word = shell_expected_out.split('{')[1].split('}')[0]
                if ("{"+word+"}") in shell_expected_out and "multipleIP" not in word and word != "":
                    shell_expected_out = shell_expected_out.replace(("{"+word+"}"), ipConfig.get("AZUREPS",word))
                if "multipleIP" in word:
                    if "Host" not in word:
                        shell_expected_out = shell_expected_out.replace(("{"+word+"}"), "multipleIP")
                    else:
                        shell_expected_out = shell_expected_out.replace(("{"+word+"}"), "multipleIPHost")
            else:
                conversionFlag = False
        '''
        if "consistency" and "-f {}" in shellcmd.lower():
            folder = ipConfig.get("AZUREPS","GoldRefFile").split(",")[0]
            file_name = ipConfig.get("AZUREPS","GoldRefFile").split(",")[1]+".ini"
            gold_path = find_folder_file(file_name, folder, AzureWD)
            shellcmd = shellcmd.replace('{}', gold_path)

        print "\nResolved Cmd: ", shellcmd
        logger.debug("Resolved Cmd: " + shellcmd)
                
        if "-i" or "-g" in shellcmd.lower():
            sut_info(shellcmd)
        if "-u " not in shellcmd.lower():
            usr = ipConfig.get("AZUREPS","Username")
            pwd = ipConfig.get("AZUREPS","Password")

        logger.debug(shellcmd)
        powershellcmd = dir_path + shellcmd
        p = subprocess.Popen([shellpath, powershellcmd], cwd=dir_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if 'fault' not in test_name.lower():
            if "update" in shellcmd:
                time.sleep(10)
                logger.debug("Are you updating the right node")
                p.stdin.write(b'y\n')
                #provisionKeys("y\n")
                #pressYes()
                #time.sleep(2)
                #enterKey()
                logger.debug("Following MS Azure stack process")
                #time.sleep(3)
                p.stdin.write(b'y\n')
                #provisionKeys("y\n")
                #pressYes()
                #time.sleep(2)
                #enterKey()

            if "provision" in shellcmd.lower():
                logger.debug("Entering password to Provision: "+str(vmPwd))
                time.sleep(10)
                provisionKeys(vmPwd)

                if apsDBpwd != "":
                    logger.debug("Entering DB Password")
                    time.sleep(10)
                    provisionKeys(apsDBpwd)

            if "power" in shellcmd.lower():
                if "off" in shellcmd.lower():
                    if "already powered off" in shell_expected_out:
                        output, error = p.communicate()
                        if "already powered off" in output:
                            executionFlag = True
                            logger.debug("Already powered off criteria met")
                    else:
                        if "multiple" in word:
                            for i in range(len(shellcmd.split("-i")[1].strip().split()[0].split(','))):
                                time.sleep(90)
                                logger.debug("Entering y for power off")
                                p.stdin.write(b'y\n')
                        #elif "single" in word:
                        else:
                            time.sleep(90)
                            logger.debug("Entering y for power off")
                            p.stdin.write(b'y\n')
                            
                elif "reset" in shellcmd.lower():
                    if "multiple" in word:
                        for i in range(len(shellcmd.split("-i")[1].strip().split()[0].split(','))):
                            logger.debug("Entering y for power reset")
                            time.sleep(8)
                            p.stdin.write(b'y\n')
                    else:
                        logger.debug("Entering y for power reset")
                        time.sleep(8)
                        p.stdin.write(b'y\n')

            if "synchronize" in shellcmd.lower():
                if "empty" in shellcmd.lower():
                    logger.debug("Entering y for synchronize")
                    provisionKeys("y")
                if "-f " in shellcmd.lower():
                    if shellcmd.lower().split("-f ")[1].split()[0] == "hosttobmc.txt" and "-u " not in shellcmd.lower() and "first" in test_name:
                        provisionKeys(usr)
                        time.sleep(3)
                        provisionKeys(pwd)

    elif option == 2:
        msmIP = ipConfig.get("IMSM","SUT")
        msmusr = ipConfig.get("IMSM","SUT_username")
        msmpwd = ipConfig.get("IMSM","SUT_password")
        msmLog = ipConfig_SharedLib.get("IMSM", "SUT_Log")

        SUT['ip'] = ipConfig.get("IMSM", 'ManagementServerIP')
        SUT['usrName'] = ipConfig.get("IMSM", 'ManagementServerUsrName')
        SUT['usrPwd'] = ipConfig.get("IMSM", 'ManagementServerPwd')

        if "{IP}" in shellcmd or "{U}" in shellcmd or "{P}" in shellcmd or "{logIP}" in shellcmd:
            shellcmd = shellcmd.replace('{IP}', msmIP).replace('{U}', msmusr).replace('{P}', msmpwd).replace("{logIP}", msmLog)
            logger.debug('Shell Cmd: ' + shellcmd)
        if "{logIP}" in shell_expected_out or "{IP}" in shell_expected_out:
            shell_expected_out = shell_expected_out.replace("{logIP}", msmLog).replace('{IP}', msmIP)
        print "\nResolved Cmd: ", shellcmd
        logger.debug("\nResolved Cmd: " + shellcmd)

        if "-i" in shellcmd and "ignore" not in test_name.lower():
            sut_info(shellcmd)

        if 'ipConfig.ini' in shellcmd:
            shellcmd="python oob.py"
            dir_path = os.path.dirname(__file__)+"/"

        if ssh.lower() == 'yes':
            logger.debug("Triggering Connect to MSM Host")
            server = connectToHost(SUT)
            message = executeCommand(server, shellcmd)
            output = ''.join(message)
            executionFlag == True
            error = ""
        else:
            p = subprocess.Popen(shellcmd, cwd=dir_path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell = True)
            if "-a" or "--OFF" or "--RESET" or "--COLD" or "customdeploy"  or "updsysfw_OOB" or "updsysfw" in shellcmd:
                logger.debug("Entering 'Y'")
                p.stdin.write(b'y\n')
            if "delete" in shellcmd:
                p.stdin.write(b'y\n')
                p.stdin.write(b'python ism_listGroups.pyc --ALL')
            if "provision" in shellcmd:
                p.stdin.write(b'\n')

    elif option == 3:
        #if "sdptool " in shellcmd.lower():
            #Read IP from IPConfig
        sdpIP = ipConfig.get("SDP","SUT")
        sdpusr = ipConfig.get("SDP","SUT_username")
        sdppwd = ipConfig.get("SDP","SUT_password")
        sdpLog = ipConfig_SharedLib.get("SDP", "SUT_Log")

        SUT['ip'] = ipConfig.get("SDP", 'SDPServerIP')
        SUT['usrName'] = ipConfig.get("SDP", 'SDPServerUsrName')
        SUT['usrPwd'] = ipConfig.get("SDP", 'SDPServerPwd')

        if "{IP}" in shellcmd or "{U}" in shellcmd or "{P}" in shellcmd or "{logIP}" in shellcmd:
            shellcmd = shellcmd.replace('{IP}', sdpIP).replace('{U}', sdpusr).replace('{P}', sdppwd).replace("{logIP}", sdpLog)
            logger.debug('Shell Cmd: ' + shellcmd)

        if "{logIP}" in shell_expected_out:
            shell_expected_out = shell_expected_out.replace("{logIP}", sdpLog)

        print "\nResolved Cmd: ", shellcmd
        logger.debug("\nResolved Cmd: " + shellcmd)

        # print "\nResolved Expected output: ", shell_expected_out
        # logger.debug("\nResolved Expected output: " + shell_expected_out)
        # time.sleep(10)

        sut_info(shellcmd)

        if ssh.lower() == 'yes':
            logger.debug("Triggering Connect to SDP Host")
            server = connectToHost(SUT)
            message = executeCommand(server, shellcmd)
            output = ''.join(message)
            executionFlag == True
            error = ""
        else:
            p = subprocess.Popen(shellcmd, cwd = cwd_name, stdin=subprocess.PIPE, stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
            if "install" in shellcmd.lower() or "getini" in shellcmd.lower() or "options" in shellcmd.lower() or "update" in shellcmd.lower():
                if "-no_user-interaction" not in shellcmd.lower():
                    logger.debug("Entering y for install/getini/options/update testcase")
                    p.stdin.write(b'y\n')

            if executionFlag == False:
                output, error = p.communicate()

            if "bmcdebuglog" in shellcmd:
                if "already exists" in output:
                    p = subprocess.Popen("python " + shellcmd, cwd=dir_path, stdin=subprocess.PIPE,
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                    p.stdin.write(b'y\n')
                    output, error = p.communicate()

        if "step_lock" in test_name.lower():
            executionFlag = True
            output, error = "",""

    #if executionFlag == False:
    #    output, error = p.communicate()



    #logger.debug("Output : " + str(output))
    #print "Output: ",output
    result, message = edit_shell_response(output, error, shell_expected_out, option)
    print "+++++++++ test_1 +++++++++", result
    if "action required" in message.lower() and result is True:
        result = False
    if "delete" in shellcmd and result == "False":
        result = True
    if result is True:
        print "_Test Result_: ", "PASS"
    else:
        print "_Test Result_: ", "FAIL"
    return result, message

def trigger_shell_ib(shellpath, test_name, shellcmd, shell_expected_out, component, cwd_name, option):
    try:
        global os_info
        os_info = getOS()
        #efi_environment = 'No'
        executable = ''
        ssh = config.get('TC_EXECUTION', 'ssh')
        executionFlag = False
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
        config.read(config_path)

        # The below OS check can be moved in common for all IB utilities
        # linux_os, win_os, efi_os = getOS()

        if option == 4:
            utility = 'OFU'
            efiFlag = 0
            if 'setoptions' in test_name or 'EFI' in test_name:
                # efi_environment = 'Yes'
                executable = ''
                efiFlag = 1
            # if win_os == 'Yes' and efiFlag == 0:
            if os_info == 'WINDOWS':
                shellcmd = 'cd ' + cwd_name + ' && ' + shellcmd
                logger.debug('Shell_Cmd_W : ' + shellcmd)

        elif option == 6:
            utility = 'SYSCFG'
            #if os_info == "UEFI" or os_info == "LINUX" or os_info == 'WINDOWS':
             #   ssh = config.get('TC_EXECUTION', 'ssh')
            # if win_os == 'Yes':
            if os_info == 'WINDOWS':
                shellcmd = 'cd ' + cwd_name + ' && ' + shellcmd
                logger.debug('Shell_Cmd_W : ' + shellcmd)

        elif option == 7:
            utility = 'IFLASH32'
            # efi_environment = 'Yes'
            if 'Upgrade' in test_name or 'Downgrade' in test_name :
                executable = 'iflash32.efi -i '+re.findall(r'[\w.]+cap',shellcmd)[0]+'\n'
            else:
                executable = ''

        elif option == 5:
            utility = 'FWPIAUPD'
            # efi_environment = config.get('TC_EXECUTION','EFI')
            # logger.debug("EFI Environment: " + efi_environment)
            logger.debug("Setting Executable Variable")
            if 'nobinswitch' in test_name.lower():
                logger.debug("NoBinSwitch Executed")
                executable = ""
                logger.debug("Executable set to null")
            else:
                if 'upgrade' in test_name.lower() or 'downgrade' in test_name.lower():
                    executable = 'fwpiaupd.efi -i ' + re.findall(r'[\w.]+bin', shellcmd)[0] + ' -bin\n'
                    logger.debug("FWPIAUPD Upgrade/Downgrade flow identified, executable set to: " + str(executable))
                else:
                    executable = ''
                    logger.debug("Executable set to null")
            '''
            if 'Upgrade' in test_name or 'Downgrade' in test_name :
                executable = 'fwpiaupd.efi -i ' + re.findall(r'[\w.]+bin', shellcmd)[0] + ' -bin\n'
                logger.debug("FWPIAUPD Upgrade/Downgrade flow identified, executable set to: " + str(executable))
            else:
                executable = ''
                logger.debug("Executable set to null")
            '''

        elif option == 8:
            utility = 'SELVIEWER'
            # efi_environment = config.get('TC_EXECUTION', 'EFI')
            # logger.debug("Selviewer in EFI Environment: " + efi_environment)
            #Uday - Added OS check for Selviewer
            #if win_os == 'Yes':
            if os_info == 'WINDOWS':
                shellcmd = 'cd ' + cwd_name + ' && ' + shellcmd
                logger.debug('Shell_Cmd_W : ' + shellcmd)

        elif option == 9:
            utility = 'FRUSDR'
            # efi_environment = 'Yes'
            executable = ''

        elif option == 10:
            utility = 'SYSINFO'
            # efi_environment = config.get('TC_EXECUTION', 'EFI')
            # windows = config.get('TC_EXECUTION', 'Windows')

            if "install" in shellcmd or "uninstall" in shellcmd:
                cwd_name = config.get('SYSINFO', 'InstallerPath')
                logger.debug("CWD is Set to: " + str(cwd_name))

        elif option == 11:
            utility = 'SPH'

        print "\nCmd: ", shellcmd
        logger.debug("\nCmd: " + shellcmd)

        SUT = {}
        if "with_admin" in test_name.lower():
            SUT['ip'] = ipConfig.get(utility, 'SUT')
            SUT['usrName'] = ipConfig.get(utility, 'adminUsrName')
            SUT['usrPwd'] = ipConfig.get(utility, 'adminUsrPwd')
        elif "without_admin" in test_name.lower() or "without_root" in test_name.lower():
            SUT['ip'] = ipConfig.get(utility, 'SUT')
            SUT['usrName'] = ipConfig.get(utility, 'nonRootName')
            SUT['usrPwd'] = ipConfig.get(utility, 'nonRootPwd')
        else:
            SUT['ip'] = ipConfig.get(utility, 'SUT')
            SUT['usrName'] = ipConfig.get(utility, 'usrName')
            SUT['usrPwd'] = ipConfig.get(utility, 'usrPwd')

        sysComponent = getFlow(test_name)
        logger.debug("SysComponent is: " + str(sysComponent))

        if "ipmi_cmd" in test_name.lower():
            executionFlag = True
            logger.debug("Initiating IPMI Command")
            result = bmc_info(shellcmd)
            message = "IPMI Command fired successfully"

        # if option ==10 and ssh.lower() == "no" and efi_environment.lower() == "no":
        if option == 10 and ssh.lower() == "no" and os_info != 'UEFI':
            logger.debug("IB tests without SHH requirement")
            executionFlag = True
            logger.debug("Trigger test in Local system")
            # if windows == "Yes":
            if os_info == 'WINDOWS':
                # from inputKeys import provisionPwd, pressYes, pressNo, enterKey
                # shellcmd = shellpath + ".\\" + shellcmd
                logger.debug("Reconstructed shell cmd: " + str(shellcmd))
                print "\nReconstructed Cmd: ", shellcmd
                # cwd_path = "C:\Users\Administrator\Documents\Sysinfo_V14_1_Build21_AllOS\Win_x64\Binaries"
                # cwd_path = config.get('SYSINFO', 'sysinfo_WD')
                cwd_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/' + utility + '\Installer\SysInfo\Win_x64\Binaries'))
                # print cwd_path
                p = subprocess.Popen(shellcmd, cwd = cwd_path , stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

            else:
                p = subprocess.Popen(shellcmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

            #if "InstWins" in test_name:
            #    time.sleep(3)
            #    logger.debug("Would you like to continue")
            #    pressYes()
            #    time.sleep(2)
            #    enterKey()
            #    logger.debug("Overwrite Criteria")
            #    time.sleep(3)
            #    pressYes()
            #    time.sleep(2)
            #    enterKey()

            if "sysinfo" in shellcmd.lower() and "/ni" not in shellcmd.lower() and "-ni" not in shellcmd.lower() and "-?" not in shellcmd.lower() and "/?" not in shellcmd.lower() and "-h" not in shellcmd.lower() and "/h" not in shellcmd.lower() and "rpm" not in shellcmd.lower():
                time.sleep(3)
                p.stdin.write(b'y\n')
                time.sleep(3)
                p.stdin.write(b'y\n')

            output, error = p.communicate()

            #logger.debug("Output : " + str(output))
            # print "\nOutput: ", str(output)
            result, message = edit_shell_response(output, error, shell_expected_out, option)

        if 'Input_files' in test_name:
            logger.debug('Input Files Condition Satisfied')
            result = ''
            message = ''
            remotePath = "/tmp/"
            logger.debug("Filesfolderpath : " + shellpath)
            logger.debug("Transferring files to remote machine now")
            transferFiles(SUT, shellpath, remotePath)
            logger.info('Files are moved from Host to SUT')
            # Execution Flag need not be added here - as it requires Connect Host method in the last

        elif 'Install' in test_name:
            logger.debug('Trigger Installation Flow')

            #installPreReq(utility)
            #Considering all linux and windows based utilities below
            if option == 4 or option == 8 or option == 6 or option == 10:
                #if linux_os == 'Yes':
                if os_info == 'LINUX':
                    remotePath = "/tmp/"

                    #Getting the exact Linux OS details
                    osCmd = "cat /etc/os-release"

                    if ssh.lower() == "no":
                        p = subprocess.Popen(osCmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                             stderr=subprocess.PIPE, shell=True)
                        output, error = p.communicate()
                    else:
                        server = connectToHost(SUT)
                        message = executeCommand(server, osCmd)
                        output = ''.join(message)
                    logger.debug("OS Query Response: " +str(output))

                    #linux OS Details will dynamically decide what flavor of Linux the distro is - RHEL 8 / Non RHEL 8 / SLES
                    installerPath = linuxOSDetails(output, utility)
                    logger.debug("RPM should be available at : " +str(installerPath))

                    # The below will retrieve the Utility folder name which has build details in it
                    folderName = os.listdir(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/Utilities/'+utility.upper()))[0]


                    if 'zip' in test_name.lower():
                        logger.debug("Linux Installation Flow Identified")
                        #*FinalCmd = 'cd /tmp/Installer/ && python Auto_zip_tools.py'
                        #**FinalCmd = 'cd /tmp/'+ utility +'/ && python Auto_zip_tools.py'
                        FinalCmd = 'cd /tmp/'+ utility +'/'+folderName+'/'+installerPath+' && '+shellcmd
                    else:
                        #*FinalCmd = 'cd /tmp/Installer/ && python Auto_tools_L.py'
                        #**FinalCmd = 'cd /tmp/'+ utility +'/ && python Auto_tools_L.py'
                        FinalCmd = 'cd /tmp/'+ utility +'/'+folderName+'/'+installerPath+' && '+shellcmd
                else:
                    print "Windows_ install..."
                    logger.debug("Windows Installation Flow Identified")
                    remotePath = r'C:\Users\Administrator\Desktop'
                    #*FinalCmd = 'cd ' + remotePath + r'\Installer\ && python Auto_tools_W.py'
                    FinalCmd = 'cd ' + remotePath + utility + r'\ && python Auto_tools_W.py'

                logger.debug("Package Installation Command: " + str(FinalCmd))
                logger.debug("Installer Path : " + shellpath)
                logger.debug("Executing Command : " + FinalCmd)

                # if ssh.lower() == "no" and linux_os == 'Yes':
                if ssh.lower() == "no" and os_info == 'LINUX':
                    #*path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages', utility, 'Installer'))+"/"
                    path = os.path.abspath(
                        os.path.join(os.path.dirname(__file__), os.pardir, 'Utilities_Packages/Utilities/', utility)) + "/"
                    #*FinalCmd = "python Auto_tools_L.py"
                    p = subprocess.Popen(FinalCmd, cwd=path, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                    output, error = p.communicate()
                    #logger.debug("Output : " + str(output))
                    print "\nOutput: ", str(output)
                    result, message = edit_shell_response(output, error, shell_expected_out, option)
                else:
                    logger.debug("Transferring files to remote machine now")
                    transferFiles(SUT, shellpath, remotePath)
                    server = connectToHost(SUT)
                    message = executeCommand(server, FinalCmd)
                    message = ''.join(message)
                    result = compare_string(server, message, shell_expected_out)
                    logger.debug("Install Message: " + message)
                    logger.debug("Install Result: " + str(result))
                executionFlag = True

        elif 'upgrade' in test_name.lower() or 'downgrade' in test_name.lower():
            logger.debug("Upgrade/Downgrade Condition Satisfied")
            executionFlag = True
            '''Start Drashti'''
            # if win_os == "Yes":
            if os_info == 'WINDOWS':
                remotePath = config.get('OFU', 'Win_Transfer')
                print ("Checking the remote path for upgrade/windows :" ,remotePath)
            # elif linux_os == "Yes":
            elif os_info == 'LINUX':
                remotePath = "/tmp/"
            '''End Drashti'''
            if option == 4 or option == 8:
                logger.debug("Creating edit.cfg file")
                create_file_text(shellpath + '//', 'edit.cfg', "", 'w+')

                execVal = getCFG(test_name)
                if "echo" not in shellcmd and (len(shellcmd.split())) > 3:
                    execVal = execVal.split()
                    execVal[1] = shellcmd.split()[3]
                    execVal = " ".join(execVal)
                    shellcmd = shellcmd.rsplit(' ', 1)[0]
                logger.debug("Retrieved Val :" + str(execVal))
                val = execVal.split(',')
                logger.debug("Entity Names : " + str(val))
                for i in val:
                    create_file_text(shellpath + '//', 'edit.cfg', i + '\n', 'a')
                '''Commented below line Drashti'''
                # remotePath = "/tmp/"
                if "nac" in test_name:
                    print "checking if going in nac of triggers"
                    '''Start Drashti'''
                    # filePath = remotePath + "\"" + os.path.basename(shellpath) + "\"/" + shellcmd.split()[-2]
                    # if linux_os == 'Yes':
                    if os_info == 'LINUX':
                        filePath = remotePath + "\"" + os.path.basename(shellpath) + "\"/" + shellcmd.split()[-2]
                    # elif win_os == 'Yes':
                    elif os_info == 'WINDOWS':
                        filePath = remotePath + "\\" + os.path.basename(shellpath) + "\\" + shellcmd.split()[-2]
                    '''End Drashti'''
                else:
                    # filePath = remotePath + "\"" + os.path.basename(shellpath) + "\"/" + shellcmd.split()[-1]
                    '''Start Drashti'''
                    #if linux_os == 'Yes':
                    if os_info == 'LINUX':
                        filePath = remotePath + "\"" + os.path.basename(shellpath) + "\"/" + shellcmd.split()[-1]
                    #elif win_os == 'Yes':
                    if os_info == 'WINDOWS':
                        filePath = remotePath + "\\" + os.path.basename(shellpath) + "\\" + shellcmd.split()[-1]
                    '''End Drashti'''

                logger.debug("ShellPath: " +shellpath+ " Shell Cmd: "+shellcmd+ " FilePath: "+filePath)
                logger.debug("Initiating Transfer Files")
                transferFiles(SUT, shellpath, remotePath)
                logger.debug("Initiating the Update Process")
                if 'nvram' in test_name.lower() or 'sdrupdate_bmc' in test_name.lower():
                    message = updateLinuxComponent(SUT, component, shellcmd, filePath, shell_expected_out, test_name)
                    result = compare_string("", message, shell_expected_out)
                else:
                    #currentVersion, targetVersion, message = updateLinuxComponent(SUT, component, shellcmd, filePath,shell_expected_out, test_name)
                    result, message = updateLinuxComponent(SUT, component, shellcmd, filePath,shell_expected_out, test_name)
                    #if "errChk" not in shell_expected_out:
                        #result = compare_string("", currentVersion, 'msg>' + str(targetVersion))
                    #else:
                        #result = message
                    #if "Update Failed" not in message:
                    #    result = compare_string("", currentVersion, 'msg>' + str(targetVersion))
                    #elif "Update Failed due to Negative test case execution" in message and "error" in shell_expected_out.lower():
                    #    result = True
                    #else:
                    #    result = False
            elif option == 5 or option == 7 or option == 4:
                logger.debug("Upgrade/Downgrade Custom Deploy flow identified")
                output, error = custom_deploy_efi(utility, shellpath, executable, shellcmd, shell_expected_out, test_name)

                if 'Nvram' in test_name or 'FD' in test_name:
                    result, message = edit_shell_response(output, error, shell_expected_out, option)
                    print "Test Result: ", result
                    return result, message

                logger.debug("Completed Upgrade/Downgrade Successfully")
                # Rakesh - to add code to validate no error in the upgrade/downgrade was noticed
                # logger.debug("Checking for failed statement in: " +str(output.lower()))
                # if 'failed' not in str(output.lower()):
                #    print "BMC Update Failed"

                if option == 5:
                    logger.debug("Calling IPMI command to get BMC version")
                    version_string = bmc_info("bmc version")
                elif option == 7:
                    time.sleep(100)
                    logger.debug("Calling IPMI command to get" + str(sysComponent) + "version")
                    version_string = bmc_info(sysComponent)

                # print "System Version: ", version_string
                logger.debug("System Version is: " + str(version_string))
                logger.debug("Package Version is: " + str(output))
                # current_version = version_string
                error_string = "IPMI Command used, no error msg generated"
                # print error_string
                logger.debug("IPMI Command used, no error msg generated: " + error_string)

                # Checking System Version matches Expected Package Version
                #   version_string  -   is from the system
                #   output          -   is the package version
                logger.debug("Checking if System Version is available in Package Version")
                if version_string in output:
                    logger.debug("Upgrade/Downgrade Successful")
                    print "Completed Upgrade/Downgrade & Current Version and Required Version is  matching"
                else:
                    logger.debug("Upgrade/Downgrade Unsuccessful. Current Version and Required Version is not matching")
                    print "Upgrade/Downgrade Unsuccessful. Current Version and Required Version is not matching"
                    print "Test Result: FALSE",
                    return False, "Current Version and Required Version is not matching"

                    '''
                    else:
                    getComponentVersion = getVersion(test_name)
                    logger.debug("Get Component Version of: " + str(getComponentVersion))
    
                    logger.debug("Waiting for a min for the system to complete the reboot")
                    time.sleep(60)
                    config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'ipConfig.ini'))
                    config.read(config_path)
                    efi_bmc_ip = config.get(utility, 'EFI')
                    logger.debug("Triggering command to get :" + getComponentVersion)
                    deploymentCmd = 'SDPTool '+efi_bmc_ip+ ' root intel@123 getbiosoptions "'+getComponentVersion+'" -no_user_interaction'
                    logger.debug("Command issued is : " + deploymentCmd)
                    ps = subprocess.Popen(deploymentCmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell = True)
                    ps.stdin.write(b'y\n')
    
                    version_string, error_string = ps.communicate()
    
                    logger.debug("Raw Output: " + version_string)
                    logger.debug("Error Output: " + error_string)
                    current_version = re.findall('Current Value[:\s]+([A-Za-z0-9.]+)', version_string)
                    logger.debug("Version from System: " +current_version[0])
                    required_version = re.findall(sysComponent.upper()+' Version[:.\s]+([A-Za-z0-9.]+)', output)
                    logger.debug("Expected version: " +required_version[0])
                    if (current_version[0] not in required_version[0]):
                        logger.debug("Current Version and Required Version is not matching")
                        return False, "Current Version and Required Version is not matching" 
                    '''

                result, message = edit_shell_response(output, error, shell_expected_out, option)

        elif 'setoption' in test_name or 'getbiosoption' in test_name:
            logger.debug('Setoption/Getbiosoption Condition Satisfied')
            executionFlag = True
            if option == 7 or option == 4 or option == 9 or option == 5 or option == 6 or option == 8 or option == 10:
                # config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'ipConfig.ini'))
                # config.read(config_path)
                efi_bmc_ip = ipConfig_SharedLib.get(utility, 'EFI_IP')
                efi_bmc_user = ipConfig_SharedLib.get(utility, 'efiUsrName')
                efi_bmc_password = ipConfig_SharedLib.get(utility, 'efiUsrPwd')
                logger.debug('BMC IP: ' + efi_bmc_ip)

                shellcmd = eval(shellcmd)
                if "{}" in shellcmd:
                    shellcmd = shellcmd.replace('{}', efi_bmc_ip + ' ' + efi_bmc_user + ' ' + efi_bmc_password).replace('\"', '')
                    logger.debug('Shell Cmd: ' + shellcmd)
                if "{bmc_ip}" in shellcmd:
                    shellcmd = shellcmd.replace('{bmc_ip}', efi_bmc_ip.replace('.', '_')).replace('\"', '')
                    logger.debug('Shell Cmd: ' + shellcmd)

                p = subprocess.Popen(shellcmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     shell=True)
                p.stdin.write(b'y\n')

                output, error = p.communicate()
                logIP = efi_bmc_ip.replace('.', '_')
                if 'setoptions' in test_name:
                    option_check = 'setoptions'
                elif 'getbiosoptions' in test_name:
                    option_check = 'getbiosoptions'
                try:
                    logIP = "/usr/local/log/SDPTool/Logfiles/" + logIP + "/" + option_check + "_output.txt"
                    logger.debug('LogFileLocation: ' + logIP)
                    output = readfile(logIP)
                except Exception, e:
                    logger.debug('Exception error: ' + str(e))
                    logIP = "/usr/local/log/SDPTool/Logfiles/" + logIP + "/" + option_check + "_output.err"
                    logger.debug('LogFileLocation: ' + logIP)
                    output = readfile(logIP)
                logger.debug('file contents: ' + output)
                logger.debug('Expected Output: ' + shell_expected_out)
                result, message = edit_shell_response(output, error, shell_expected_out, option)

        # elif executionFlag == False and (efi_environment == 'Yes' or 'EFI' in test_name):
        elif executionFlag == False and (os_info == 'UEFI' or 'EFI' in test_name):
            executionFlag = True
            if option == 9 or option == 5 or option == 6 or option == 8:
                if re.search("{[\w._]+}", shellcmd):
                    config_value = re.findall("{([\w._]+)}", shellcmd)[0]
                    # config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'Datafeed', 'config.ini'))
                    # config.read(config_path)
                    config_parse_value = config.get(utility, config_value).replace('\"', '')
                    shellcmd = shellcmd.replace(config_value, config_parse_value).replace('{', '').replace('}', '')
                    logger.debug("Shell Command is:    " + shellcmd)
                    print(shellcmd)

            logger.debug("Initiating Custom Deploy EFI flow")
            output, error = custom_deploy_efi(utility, shellpath, executable, shellcmd, shell_expected_out, test_name)
            logger.debug("Calling Edit Shell response to verify result")
            result, message = edit_shell_response(output, error, shell_expected_out, option)

        elif "IPMI_Driver_Check" in test_name:
            if option == 8:
                server = connectToHost(SUT)
                cmd_ipmi_status_1 = 'service ipmi status'
                message = executeCommand(server, cmd_ipmi_status_1)
                message = ''.join(message)
                if 'ipmi.service could not be found' in message:
                    logger.info('ipmi is not installed in this OS')
                    logger.debug('ipmi is not installed in this OS')
                    result = False
                elif 'Active: inactive' in message:
                    cmd_ipmi_start_2 = 'service ipmi start'
                    message = executeCommand(server, cmd_ipmi_start_2)
                    message = ''.join(message)
                    if 'start ipmmi.service' in message:
                        logger.debug('The ipmi is started')
                        result = True
                    else:
                        logger.debug('The ipmi is already started')
                        result = True
                elif 'Active: active' in message:
                    logger.debug('The ipmi is already started')
                    result = True
                else:
                    message = 'Could not find Ipmi driver'
                    logger.debug('Could not found Ipmi driver')
                    result = False

        elif executionFlag == False:
            logger.debug("Execution Flag is False")
            if ssh.lower() == 'yes':
                logger.debug("Triggering Connect to Host")
                server = connectToHost(SUT)
                message = executeCommand(server, shellcmd)
                message = ''.join(message)
                if "driver_check" in test_name.lower():
                    print "going inside IPMI test case for OFU"
                    message = message.encode("utf-8")

                if option == 10 and ('SYSINFO_' in test_name or 'Generate_Log' in test_name):
                    logger.debug("Retrieving the Sysinfo Logfiles folder from remote system to local")
                    print "Local Path: " + str(os.path.abspath(os.path.join(os.path.abspath(__file__), os.pardir)))
                    # server = connectToHost(SUT)
                    # server, localpath, remotePath
                    transferRemoteFiles(server, os.path.abspath(os.path.join(os.path.abspath(__file__), os.pardir)),
                                        r'/root/LogFiles')
                    logger.debug("Unzip the transferred folder")
                    unzipCmd = UNZIP_TAR_GZ_CMD + "  temp.tar.gz"
                    executeCommand("", unzipCmd)
                else:
                    logger.debug("Sysinfo log not retrieved from remote host")


                logger.debug("Analyzing the results")
                result = compare_string(server , message, shell_expected_out)
                server.close()
            else:
                logger.debug("Executing command [" +str(shellcmd)+"] in local host")
                p = subprocess.Popen(shellcmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, shell=True)
                output, error = p.communicate()
                # logger.debug("Output : " + str(output))
                print "\nOutput: ", str(output)
                result, message = edit_shell_response(output, error, shell_expected_out, option)

        print "Test Result: ", result
        return result, message
    except Exception, msg:
        logger.debug("Exception in Inband Trigger Shell: " + str(msg))
