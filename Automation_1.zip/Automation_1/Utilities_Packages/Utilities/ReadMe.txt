- Copy the unzipped utility folder into respective folder
Ex: Copy Syscfg_V14_1_Build28AllOS into SYSCFG folder